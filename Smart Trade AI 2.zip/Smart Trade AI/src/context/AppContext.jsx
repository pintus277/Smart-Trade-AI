import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  getStoredProducts,
  saveProduct,
  updateStoredProduct,
  deleteStoredProduct,
  getCurrentUser,
  setCurrentUser as saveCurrentUser,
  getWishlistIds,
  toggleWishlistId,
  getStoredMessages,
  sendStoredMessage
} from '../services/storage';

const AppContext = createContext();

export function AppProvider({ children }) {
  const [currentUser, setCurrentUser] = useState(null);
  const [products, setProducts] = useState([]);
  const [wishlist, setWishlist] = useState([]);
  const [messages, setMessages] = useState([]);
  const [activeScreen, setActiveScreen] = useState('home'); // 'home' | 'search' | 'sell' | 'messages' | 'profile' | 'product_detail' | 'my_products' | 'wishlist' | 'auth'
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [activeChatThread, setActiveChatThread] = useState(null); // { productId, sellerId }
  const [toast, setToast] = useState(null); // { type, message }

  // Load initial data
  useEffect(() => {
    const user = getCurrentUser();
    const loadedProducts = getStoredProducts();
    const loadedWishlist = getWishlistIds();
    const loadedMessages = getStoredMessages();

    setCurrentUser(user);
    setProducts(loadedProducts);
    setWishlist(loadedWishlist);
    setMessages(loadedMessages);
  }, []);

  // Show Toast Message
  const showToast = (message, type = 'info') => {
    setToast({ message, type });
    setTimeout(() => {
      setToast(null);
    }, 3500);
  };

  // Toggle Favorite
  const toggleFavorite = (productId) => {
    const updated = toggleWishlistId(productId);
    setWishlist(updated);
    if (updated.includes(productId)) {
      showToast('Product added to your Wishlist ♥', 'success');
    } else {
      showToast('Product removed from Wishlist', 'info');
    }
  };

  // Navigation Helper
  const navigateTo = (screen, param = null) => {
    if (screen === 'product_detail' && param) {
      setSelectedProduct(param);
    }
    if (screen === 'chat_thread' && param) {
      setActiveChatThread(param);
      setActiveScreen('messages');
      return;
    }
    setActiveScreen(screen);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Add Product
  const addProduct = (productData) => {
    const created = saveProduct({
      ...productData,
      sellerId: currentUser?.id || 'user-demo-1',
      sellerName: currentUser?.name || 'Rahul Sharma',
      sellerPhone: currentUser?.phone || '+91 98765 43210',
      sellerCity: currentUser?.city || 'Bengaluru',
      sellerState: currentUser?.state || 'Karnataka',
      sellerPincode: currentUser?.pincode || '560001'
    });
    setProducts(getStoredProducts());
    showToast('🎉 Product published to marketplace!', 'success');
    navigateTo('home');
    return created;
  };

  // Update Product
  const editProduct = (id, updatedFields) => {
    const updated = updateStoredProduct(id, updatedFields);
    setProducts(getStoredProducts());
    showToast('Product listing updated successfully', 'success');
    return updated;
  };

  // Mark Product as Sold
  const markAsSold = (id) => {
    editProduct(id, { status: 'Sold' });
    showToast('Product status updated to SOLD', 'info');
  };

  // Delete Product
  const removeProduct = (id) => {
    deleteStoredProduct(id);
    setProducts(getStoredProducts());
    showToast('Product deleted from marketplace', 'info');
  };

  // Send Chat Message
  const sendMessage = (productId, receiverId, receiverName, productName, text) => {
    if (!text.trim()) return;
    const newMsg = sendStoredMessage({
      productId,
      senderId: currentUser?.id || 'user-1',
      receiverId,
      senderName: currentUser?.name || 'Buyer',
      receiverName,
      productName,
      message: text
    });
    setMessages(getStoredMessages());
    showToast('Message sent to seller 💬', 'success');
    return newMsg;
  };

  // User Auth - Login
  const loginUser = (email, password) => {
    const user = {
      id: `user-${Date.now()}`,
      name: email.split('@')[0] || 'User',
      email,
      phone: '+91 98765 43210',
      address: '104, Green Glen Layout',
      city: 'Bengaluru',
      state: 'Karnataka',
      pincode: '560103'
    };
    setCurrentUser(user);
    saveCurrentUser(user);
    showToast(`Welcome back, ${user.name}!`, 'success');
    navigateTo('home');
  };

  // User Auth - Register
  const registerUser = (userData) => {
    const newUser = {
      id: `user-${Date.now()}`,
      ...userData
    };
    setCurrentUser(newUser);
    saveCurrentUser(newUser);
    showToast('Account registered successfully! Welcome to Smart Trade AI.', 'success');
    navigateTo('home');
  };

  // Logout
  const logoutUser = () => {
    setCurrentUser(null);
    saveCurrentUser(null);
    showToast('Logged out of Smart Trade AI', 'info');
    navigateTo('home');
  };

  const value = {
    currentUser,
    products,
    wishlist,
    messages,
    activeScreen,
    selectedProduct,
    selectedCategory,
    searchQuery,
    activeChatThread,
    toast,
    setSelectedCategory,
    setSearchQuery,
    navigateTo,
    toggleFavorite,
    addProduct,
    editProduct,
    markAsSold,
    removeProduct,
    sendMessage,
    loginUser,
    registerUser,
    logoutUser,
    showToast
  };

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

export function useApp() {
  return useContext(AppContext);
}
