/**
 * Storage Service - Local Database Manager & Data Seeder
 */

const STORAGE_KEYS = {
  USERS: 'smart_trade_users',
  PRODUCTS: 'smart_trade_products',
  CURRENT_USER: 'smart_trade_current_user',
  MESSAGES: 'smart_trade_messages',
  WISHLIST: 'smart_trade_wishlist'
};

// Seed Products Dataset
const INITIAL_PRODUCTS = [
  {
    id: 'prod-1',
    sellerId: 'user-demo-1',
    sellerName: 'Rahul Sharma',
    sellerPhone: '+91 98765 43210',
    sellerCity: 'Bengaluru',
    sellerState: 'Karnataka',
    sellerPincode: '560001',
    name: 'Samsung Galaxy S21 5G (Phantom Gray)',
    category: 'Smartphones',
    brand: 'Samsung',
    model: 'Galaxy S21 5G (128GB)',
    purchaseYear: 2021,
    age: '3 years',
    originalPrice: 70000,
    sellingPrice: 24000,
    aiPredictedPrice: {
      recommendedPrice: 24000,
      minimumPrice: 22000,
      maximumPrice: 26000,
      confidenceScore: 94,
      reasoning: 'Based on 3 years age, good physical condition, fully working AMOLED display, original charger included, and expired warranty, AI predicts ₹24,000.'
    },
    condition: 'Good',
    workingStatus: 'Fully Working',
    physicalCondition: 'Minor Scratches on back cover',
    usageDuration: '2.5 years',
    damage: 'Minor hairline scratches on back body',
    missingComponents: 'None',
    accessories: ['Original Charger', 'Box & Bill', 'Protective Case'],
    warrantyStatus: 'Expired',
    warrantyPeriod: '0',
    specs: '8GB RAM | 128GB Storage | Exynos 2100 | 120Hz AMOLED',
    repairHistory: 'None - All original parts',
    reasonForSelling: 'Upgraded to Galaxy S24 Ultra',
    image: 'https://images.unsplash.com/photo-1610945265064-0e34e5519bbf?auto=format&fit=crop&w=800&q=80',
    status: 'Available',
    createdAt: '2026-08-25T10:30:00Z',
    isFeatured: true
  },
  {
    id: 'prod-2',
    sellerId: 'user-demo-2',
    sellerName: 'Ananya Patel',
    sellerPhone: '+91 98220 11223',
    sellerCity: 'Mumbai',
    sellerState: 'Maharashtra',
    sellerPincode: '400001',
    name: 'Apple MacBook Pro 13" M1 (8GB / 256GB SSD)',
    category: 'Laptops',
    brand: 'Apple',
    model: 'MacBook Pro 13-inch M1 (2020)',
    purchaseYear: 2022,
    age: '2 years',
    originalPrice: 122900,
    sellingPrice: 58000,
    aiPredictedPrice: {
      recommendedPrice: 58500,
      minimumPrice: 54000,
      maximumPrice: 62000,
      confidenceScore: 96,
      reasoning: 'High resale retention M1 chip, immaculate aluminum body, 91% battery health, original 61W USB-C brick included. AI recommended ₹58,500.'
    },
    condition: 'Like New',
    workingStatus: 'Fully Working',
    physicalCondition: 'Flawless condition with screen guard',
    usageDuration: '1.5 years',
    damage: 'None',
    missingComponents: 'None',
    accessories: ['Original Charger', 'Box & Bill', 'USB-C Cable'],
    warrantyStatus: 'Expired',
    warrantyPeriod: '0',
    specs: 'Apple M1 Chip | 8GB Unified RAM | 256GB NVMe SSD | Retina Display',
    repairHistory: 'None',
    reasonForSelling: 'Company provided M3 Pro workstation',
    image: 'https://images.unsplash.com/photo-1517336714731-489689fd1ca8?auto=format&fit=crop&w=800&q=80',
    status: 'Available',
    createdAt: '2026-08-26T14:15:00Z',
    isFeatured: true
  },
  {
    id: 'prod-3',
    sellerId: 'user-demo-3',
    sellerName: 'Vikram Singh',
    sellerPhone: '+91 97111 88990',
    sellerCity: 'Delhi',
    sellerState: 'Delhi',
    sellerPincode: '110001',
    name: 'Asus ROG Strix NVIDIA GeForce RTX 3080 10GB GPU',
    category: 'Graphics Cards',
    brand: 'NVIDIA',
    model: 'ROG-STRIX-RTX3080-O10G-GAMING',
    purchaseYear: 2021,
    age: '3 years',
    originalPrice: 95000,
    sellingPrice: 38000,
    aiPredictedPrice: {
      recommendedPrice: 37500,
      minimumPrice: 34000,
      maximumPrice: 41000,
      confidenceScore: 92,
      reasoning: 'High performance gaming GPU, triple fan cooling system, stress tested at sub-68°C temps. AI recommended price is ₹37,500.'
    },
    condition: 'Good',
    workingStatus: 'Fully Working',
    physicalCondition: 'Clean heatsink, no dust buildup',
    usageDuration: '2 years casual gaming',
    damage: 'None (Never mined)',
    missingComponents: 'None',
    accessories: ['Box & Bill', 'Anti-Static Bag', 'GPU Support Bracket'],
    warrantyStatus: 'Expired',
    warrantyPeriod: '0',
    specs: '10GB GDDR6X | PCIe 4.0 | ARGB Lighting | Triple Axial Fans',
    repairHistory: 'Thermal pads repasted with Gelid Extreme in 2025',
    reasonForSelling: 'Upgraded to RTX 4080 Super',
    image: 'https://images.unsplash.com/photo-1591488320449-011701bb6704?auto=format&fit=crop&w=800&q=80',
    status: 'Available',
    createdAt: '2026-08-24T09:00:00Z',
    isFeatured: true
  },
  {
    id: 'prod-4',
    sellerId: 'user-demo-1',
    sellerName: 'Rahul Sharma',
    sellerPhone: '+91 98765 43210',
    sellerCity: 'Bengaluru',
    sellerState: 'Karnataka',
    sellerPincode: '560001',
    name: 'Corsair Vengeance LPX 16GB (2x8GB) DDR4 3200MHz RAM',
    category: 'RAM',
    brand: 'Corsair',
    model: 'CMK16GX4M2E3200C16',
    purchaseYear: 2023,
    age: '1 year',
    originalPrice: 5200,
    sellingPrice: 2800,
    aiPredictedPrice: {
      recommendedPrice: 2700,
      minimumPrice: 2400,
      maximumPrice: 3000,
      confidenceScore: 95,
      reasoning: 'DDR4 high memory compatibility, dual channel kit with lifetime manufacturer warranty remaining. AI recommended price ₹2,700.'
    },
    condition: 'Like New',
    workingStatus: 'Fully Working',
    physicalCondition: 'Spotless black aluminum heat spreader',
    usageDuration: '10 months',
    damage: 'None',
    missingComponents: 'None',
    accessories: ['Original Retail Box', 'Invoice Bill'],
    warrantyStatus: 'Active',
    warrantyPeriod: '96',
    specs: '16GB (8GBx2) | DDR4 | 3200MHz | CL16 | 1.35V',
    repairHistory: 'None',
    reasonForSelling: 'Upgraded PC to 64GB DDR5 setup',
    image: 'https://images.unsplash.com/photo-1562976540-1502c2145186?auto=format&fit=crop&w=800&q=80',
    status: 'Available',
    createdAt: '2026-08-27T08:20:00Z',
    isFeatured: false
  },
  {
    id: 'prod-5',
    sellerId: 'user-demo-4',
    sellerName: 'Priya Sundaram',
    sellerPhone: '+91 94440 55667',
    sellerCity: 'Chennai',
    sellerState: 'Tamil Nadu',
    sellerPincode: '600001',
    name: 'Sony WH-1000XM4 Wireless Noise Cancelling Headphones',
    category: 'Audio Devices',
    brand: 'Sony',
    model: 'WH-1000XM4 Black',
    purchaseYear: 2022,
    age: '2 years',
    originalPrice: 29990,
    sellingPrice: 13500,
    aiPredictedPrice: {
      recommendedPrice: 13800,
      minimumPrice: 12500,
      maximumPrice: 15000,
      confidenceScore: 93,
      reasoning: 'Industry leading ANC, 30hr battery backup, plush earcups replaced with new protein leather cushions. AI evaluated at ₹13,800.'
    },
    condition: 'Good',
    workingStatus: 'Fully Working',
    physicalCondition: 'Clean headband, minor scuff on left outer cup',
    usageDuration: '1.8 years',
    damage: 'Tiny surface scuff on outer ear cup',
    missingComponents: 'None',
    accessories: ['Hard Carrying Case', '3.5mm Aux Cable', 'Flight Adapter', 'USB-C Cable'],
    warrantyStatus: 'Expired',
    warrantyPeriod: '0',
    specs: 'Active Noise Cancelling | 30h Battery | Touch Control | LDAC Codec',
    repairHistory: 'New earpads installed in Jan 2026',
    reasonForSelling: 'Switched to AirPods Max',
    image: 'https://images.unsplash.com/photo-1546435770-a3e426bf472b?auto=format&fit=crop&w=800&q=80',
    status: 'Available',
    createdAt: '2026-08-23T11:45:00Z',
    isFeatured: false
  }
];

// Seed Initial Messages
const INITIAL_MESSAGES = [
  {
    id: 'msg-1',
    productId: 'prod-1',
    senderId: 'user-demo-2', // Ananya
    receiverId: 'user-demo-1', // Rahul
    senderName: 'Ananya Patel',
    receiverName: 'Rahul Sharma',
    productName: 'Samsung Galaxy S21 5G',
    message: 'Hi Rahul! Is the Samsung Galaxy S21 still available? Can we meet in Indiranagar?',
    timestamp: '2026-08-26T16:20:00Z',
    readStatus: false
  },
  {
    id: 'msg-2',
    productId: 'prod-1',
    senderId: 'user-demo-1',
    receiverId: 'user-demo-2',
    senderName: 'Rahul Sharma',
    receiverName: 'Ananya Patel',
    productName: 'Samsung Galaxy S21 5G',
    message: 'Yes Ananya! It is available. Indiranagar is fine. Let me know what time works best.',
    timestamp: '2026-08-26T16:25:00Z',
    readStatus: true
  }
];

// Demo Users
const INITIAL_USERS = [
  {
    id: 'user-demo-1',
    name: 'Rahul Sharma',
    email: 'rahul@smarttrade.ai',
    phone: '+91 98765 43210',
    password: 'password123',
    address: '104, Green Glen Layout, Bellandur',
    city: 'Bengaluru',
    state: 'Karnataka',
    pincode: '560103',
    profileImage: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=400&q=80'
  }
];

export function initializeStorage() {
  if (!localStorage.getItem(STORAGE_KEYS.PRODUCTS)) {
    localStorage.setItem(STORAGE_KEYS.PRODUCTS, JSON.stringify(INITIAL_PRODUCTS));
  }
  if (!localStorage.getItem(STORAGE_KEYS.USERS)) {
    localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(INITIAL_USERS));
  }
  if (!localStorage.getItem(STORAGE_KEYS.MESSAGES)) {
    localStorage.setItem(STORAGE_KEYS.MESSAGES, JSON.stringify(INITIAL_MESSAGES));
  }
  if (!localStorage.getItem(STORAGE_KEYS.WISHLIST)) {
    localStorage.setItem(STORAGE_KEYS.WISHLIST, JSON.stringify(['prod-1', 'prod-3']));
  }
  if (!localStorage.getItem(STORAGE_KEYS.CURRENT_USER)) {
    localStorage.setItem(STORAGE_KEYS.CURRENT_USER, JSON.stringify(null));
  }
}

// Products API
export function getStoredProducts() {
  initializeStorage();
  try {
    return JSON.parse(localStorage.getItem(STORAGE_KEYS.PRODUCTS)) || [];
  } catch (e) {
    return INITIAL_PRODUCTS;
  }
}

export function saveProduct(productData) {
  const products = getStoredProducts();
  const newProduct = {
    id: `prod-${Date.now()}`,
    createdAt: new Date().toISOString(),
    status: 'Available',
    isFeatured: false,
    ...productData
  };
  products.unshift(newProduct);
  localStorage.setItem(STORAGE_KEYS.PRODUCTS, JSON.stringify(products));
  return newProduct;
}

export function updateStoredProduct(id, updatedFields) {
  const products = getStoredProducts();
  const index = products.findIndex(p => p.id === id);
  if (index !== -1) {
    products[index] = { ...products[index], ...updatedFields };
    localStorage.setItem(STORAGE_KEYS.PRODUCTS, JSON.stringify(products));
    return products[index];
  }
  return null;
}

export function deleteStoredProduct(id) {
  const products = getStoredProducts();
  const filtered = products.filter(p => p.id !== id);
  localStorage.setItem(STORAGE_KEYS.PRODUCTS, JSON.stringify(filtered));
  return true;
}

// Current User Session
export function getCurrentUser() {
  initializeStorage();
  try {
    const data = localStorage.getItem(STORAGE_KEYS.CURRENT_USER);
    return data ? JSON.parse(data) : null;
  } catch (e) {
    return null;
  }
}

export function setCurrentUser(user) {
  localStorage.setItem(STORAGE_KEYS.CURRENT_USER, JSON.stringify(user));
}

// Wishlist API
export function getWishlistIds() {
  initializeStorage();
  try {
    return JSON.parse(localStorage.getItem(STORAGE_KEYS.WISHLIST)) || [];
  } catch (e) {
    return [];
  }
}

export function toggleWishlistId(productId) {
  const ids = getWishlistIds();
  let updated;
  if (ids.includes(productId)) {
    updated = ids.filter(id => id !== productId);
  } else {
    updated = [...ids, productId];
  }
  localStorage.setItem(STORAGE_KEYS.WISHLIST, JSON.stringify(updated));
  return updated;
}

// Messages API
export function getStoredMessages() {
  initializeStorage();
  try {
    return JSON.parse(localStorage.getItem(STORAGE_KEYS.MESSAGES)) || [];
  } catch (e) {
    return INITIAL_MESSAGES;
  }
}

export function sendStoredMessage(msgObj) {
  const messages = getStoredMessages();
  const newMsg = {
    id: `msg-${Date.now()}`,
    timestamp: new Date().toISOString(),
    readStatus: false,
    ...msgObj
  };
  messages.push(newMsg);
  localStorage.setItem(STORAGE_KEYS.MESSAGES, JSON.stringify(messages));
  return newMsg;
}
