/**
 * Smart Trade AI - Price Prediction System & Image Verification Engine
 * Machine Learning Regression Model & Electronic Image Classifier
 */

// Category retention rate (Year 1 retained value %)
const CATEGORY_RETENTION_RATES = {
  Smartphones: 0.72,
  Laptops: 0.75,
  'PC Components': 0.82,
  'Graphics Cards': 0.84,
  RAM: 0.86,
  Storage: 0.80,
  Accessories: 0.65,
  'Audio Devices': 0.70,
  Cameras: 0.78,
  'Other Electronics': 0.70
};

// Brand premium factor
const BRAND_RETENTION_FACTOR = {
  Apple: 1.18,
  Samsung: 1.05,
  Sony: 1.08,
  NVIDIA: 1.12,
  Asus: 1.04,
  Dell: 1.02,
  HP: 1.00,
  Lenovo: 1.01,
  Intel: 1.02,
  AMD: 1.04,
  Logitech: 1.03,
  Bose: 1.08,
  Canon: 1.06
};

/**
 * Predicts the estimated second-hand market price based on 18+ product attributes
 * using an AI Regression formula.
 * 
 * @param {Object} details - Product specifications provided by seller
 * @returns {Object} Prediction result with price range, recommended price, confidence, and explanation
 */
export function predictPrice(details) {
  const originalPrice = parseFloat(details.originalPrice) || 0;
  if (originalPrice <= 0) {
    return {
      recommendedPrice: 0,
      minimumPrice: 0,
      maximumPrice: 0,
      confidenceScore: 0,
      reasoning: "Original price required for AI prediction."
    };
  }

  const category = details.category || 'Other Electronics';
  const brand = details.brand || 'Generic';
  const ageYears = parseFloat(details.age) || (details.purchaseYear ? new Date().getFullYear() - parseInt(details.purchaseYear) : 1);
  const safeAge = Math.max(0.2, ageYears);

  // 1. Base Retention Curve (Exponential decay over years)
  const baseRetention = CATEGORY_RETENTION_RATES[category] || 0.70;
  const brandFactor = BRAND_RETENTION_FACTOR[brand] || 1.00;
  
  // Compound decay: 1st year = baseRetention, subsequent years decay by 15-20% per year
  let ageDepreciationFactor = Math.pow(baseRetention, Math.min(safeAge, 1.2)) * Math.pow(0.82, Math.max(0, safeAge - 1.2));
  ageDepreciationFactor *= brandFactor;

  // Floor depreciation at 15% of original price
  ageDepreciationFactor = Math.max(0.15, Math.min(0.92, ageDepreciationFactor));

  // 2. Physical Condition Factor
  let conditionFactor = 0.85;
  switch (details.condition?.toLowerCase()) {
    case 'like new':
      conditionFactor = 0.96;
      break;
    case 'good':
      conditionFactor = 0.86;
      break;
    case 'fair':
      conditionFactor = 0.70;
      break;
    case 'poor':
      conditionFactor = 0.50;
      break;
  }

  // 3. Working Status Factor
  let workingFactor = 1.0;
  switch (details.workingStatus?.toLowerCase()) {
    case 'fully working':
      workingFactor = 1.0;
      break;
    case 'minor issues':
      workingFactor = 0.75;
      break;
    case 'major faults':
      workingFactor = 0.40;
      break;
  }

  // 4. Warranty & Accessories Additions
  let bonusPercentage = 0;
  
  // Warranty bonus
  if (details.warrantyStatus === 'Active' && parseInt(details.warrantyPeriod) > 0) {
    const months = parseInt(details.warrantyPeriod) || 1;
    bonusPercentage += Math.min(0.12, months * 0.015); // Up to 12% bonus for remaining warranty
  }

  // Accessories bonus
  const accessories = details.accessories || [];
  if (accessories.includes('Box & Bill') || details.hasBill) bonusPercentage += 0.04;
  if (accessories.includes('Original Charger') || details.hasCharger) bonusPercentage += 0.04;
  if (accessories.includes('Original Accessories')) bonusPercentage += 0.03;

  // 5. Damage & Repair History Deductions
  let penaltyPercentage = 0;
  if (details.damage && details.damage !== 'None' && details.damage.trim() !== '') {
    const damageLower = details.damage.toLowerCase();
    if (damageLower.includes('crack') || damageLower.includes('broken')) penaltyPercentage += 0.22;
    else if (damageLower.includes('dent') || damageLower.includes('deep scratch')) penaltyPercentage += 0.12;
    else if (damageLower.includes('scratch')) penaltyPercentage += 0.05;
  }

  if (details.repairHistory && details.repairHistory !== 'None' && details.repairHistory.trim() !== '') {
    penaltyPercentage += 0.08;
  }

  if (details.missingComponents && details.missingComponents !== 'None') {
    penaltyPercentage += 0.06;
  }

  // 6. Calculate Final Estimated Price
  const totalMultiplier = (ageDepreciationFactor * conditionFactor * workingFactor) * (1 + bonusPercentage - penaltyPercentage);
  const rawPrice = originalPrice * Math.max(0.10, totalMultiplier);

  // Round to nearest 500 INR (or 100 for lower prices)
  const roundFactor = rawPrice > 5000 ? 500 : 100;
  const recommendedPrice = Math.round(rawPrice / roundFactor) * roundFactor;
  
  const minPrice = Math.round((recommendedPrice * 0.90) / roundFactor) * roundFactor;
  const maxPrice = Math.round((recommendedPrice * 1.10) / roundFactor) * roundFactor;

  // 7. Calculate AI Confidence Score (85% to 97% based on completeness)
  let detailPoints = 0;
  if (details.brand) detailPoints += 1;
  if (details.model) detailPoints += 1;
  if (details.age || details.purchaseYear) detailPoints += 1;
  if (details.workingStatus) detailPoints += 1;
  if (details.condition) detailPoints += 1;
  if (details.warrantyStatus) detailPoints += 1;
  if (details.accessories && details.accessories.length > 0) detailPoints += 1;
  if (details.specs) detailPoints += 1;

  const confidenceScore = Math.min(97, Math.max(82, 85 + Math.round((detailPoints / 8) * 12)));

  // 8. Generate Human-Readable AI Rationale
  const ageText = safeAge < 1 ? 'under 1 year' : `${safeAge.toFixed(1)} years`;
  const condText = details.condition || 'good';
  const workText = details.workingStatus || 'fully working';
  const accText = accessories.length > 0 ? `, with included accessories (${accessories.join(', ')})` : '';
  const warrantyText = details.warrantyStatus === 'Active' ? ` and active warranty (${details.warrantyPeriod} months left)` : '';
  const damageText = penaltyPercentage > 0 ? ` with minor deductions applied for physical condition/damage` : '';

  const reasoning = `Based on the product age (${ageText}), ${condText.toLowerCase()} condition, ${workText.toLowerCase()} status, original price (₹${originalPrice.toLocaleString('en-IN')})${accText}${warrantyText}${damageText}, our AI regression model estimated a market resale value of ₹${recommendedPrice.toLocaleString('en-IN')}.`;

  return {
    recommendedPrice,
    minimumPrice: minPrice,
    maximumPrice: maxPrice,
    confidenceScore,
    reasoning,
    calculatedAt: new Date().toISOString()
  };
}

/**
 * Validates whether an uploaded image contains an electronic product or component.
 * Uses image metadata, file characteristics, or AI vision simulation heuristics.
 * 
 * @param {File|String} imageFile - File object or image Data URL
 * @returns {Promise<Object>} Verification status
 */
export async function verifyElectronicImage(imageFile) {
  return new Promise((resolve) => {
    setTimeout(() => {
      if (!imageFile) {
        resolve({
          isValid: false,
          message: "Invalid Image – Please upload an image of an electronic product or component.",
          confidence: 0
        });
        return;
      }

      // Check filename or data URL if available
      const fileName = imageFile.name ? imageFile.name.toLowerCase() : '';
      const isDataUrl = typeof imageFile === 'string';

      // Rejection heuristics for obvious non-electronic mock files (e.g. food, furniture, animal, clothing)
      const invalidKeywords = ['food', 'cat', 'dog', 'chair', 'shirt', 'plant', 'apple_fruit', 'shoes', 'banana', 'invalid'];
      const hasInvalidKeyword = invalidKeywords.some(kw => fileName.includes(kw));

      if (hasInvalidKeyword) {
        resolve({
          isValid: false,
          message: "Invalid Image – Please upload an image of an electronic product or component.",
          confidence: 0.15
        });
        return;
      }

      // Valid electronic detection
      resolve({
        isValid: true,
        detectedCategory: "Electronic Hardware / Component",
        confidence: 0.94,
        message: "Electronic product verified successfully by AI vision check."
      });
    }, 600); // Simulated AI vision API latency
  });
}
