import React, { useState } from 'react';
import { Search, SlidersHorizontal, MapPin, Sparkles, Heart, RotateCcw, X, Filter } from 'lucide-react';
import { useApp } from '../context/AppContext';

const CATEGORIES = [
  'All',
  'Smartphones',
  'Laptops',
  'PC Components',
  'Graphics Cards',
  'RAM',
  'Storage',
  'Accessories',
  'Audio Devices',
  'Cameras',
  'Other Electronics'
];

const CONDITIONS = ['All', 'Like New', 'Good', 'Fair', 'Poor'];

export function SearchScreen() {
  const { products, wishlist, navigateTo, toggleFavorite, searchQuery, setSearchQuery } = useApp();

  const [selectedCategory, setSelectedCategory] = useState('All');
  const [selectedCondition, setSelectedCondition] = useState('All');
  const [minPrice, setMinPrice] = useState('');
  const [maxPrice, setMaxPrice] = useState('');
  const [locationQuery, setLocationQuery] = useState('');
  const [sortBy, setSortBy] = useState('newest'); // 'newest' | 'price_low' | 'price_high'
  const [showFilterDrawer, setShowFilterDrawer] = useState(false);

  // Filter & Search Logic
  const filteredProducts = products.filter((product) => {
    // Text search
    const q = searchQuery.toLowerCase().trim();
    const matchesText = !q ||
      product.name.toLowerCase().includes(q) ||
      product.brand.toLowerCase().includes(q) ||
      product.model.toLowerCase().includes(q) ||
      product.category.toLowerCase().includes(q);

    // Location search
    const loc = locationQuery.toLowerCase().trim();
    const matchesLoc = !loc ||
      (product.sellerCity && product.sellerCity.toLowerCase().includes(loc)) ||
      (product.sellerState && product.sellerState.toLowerCase().includes(loc));

    // Category filter
    const matchesCat = selectedCategory === 'All' || product.category === selectedCategory;

    // Condition filter
    const matchesCond = selectedCondition === 'All' || product.condition === selectedCondition;

    // Price range filter
    const price = product.sellingPrice || 0;
    const matchesMin = !minPrice || price >= parseFloat(minPrice);
    const matchesMax = !maxPrice || price <= parseFloat(maxPrice);

    return matchesText && matchesLoc && matchesCat && matchesCond && matchesMin && matchesMax;
  }).sort((a, b) => {
    if (sortBy === 'price_low') return a.sellingPrice - b.sellingPrice;
    if (sortBy === 'price_high') return b.sellingPrice - a.sellingPrice;
    return new Date(b.createdAt) - new Date(a.createdAt); // newest
  });

  const resetFilters = () => {
    setSearchQuery('');
    setSelectedCategory('All');
    setSelectedCondition('All');
    setMinPrice('');
    setMaxPrice('');
    setLocationQuery('');
    setSortBy('newest');
  };

  const renderFilterFields = () => (
    <>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
        <h4 style={{ fontFamily: 'Outfit, sans-serif', fontWeight: 800, fontSize: '1rem', color: '#09090b', display: 'flex', alignItems: 'center', gap: '6px' }}>
          <Filter size={18} color="#7c3aed" /> Marketplace Filters
        </h4>
        <button onClick={resetFilters} style={{ background: 'none', border: 'none', color: '#7c3aed', fontSize: '0.8rem', fontWeight: 700, cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '4px' }}>
          <RotateCcw size={14} /> Reset
        </button>
      </div>

      {/* Category Dropdown */}
      <div className="input-group">
        <label className="input-label">Category</label>
        <select
          className="select-field"
          value={selectedCategory}
          onChange={(e) => setSelectedCategory(e.target.value)}
        >
          {CATEGORIES.map(cat => (
            <option key={cat} value={cat}>{cat}</option>
          ))}
        </select>
      </div>

      {/* Condition Dropdown */}
      <div className="input-group">
        <label className="input-label">Item Condition</label>
        <select
          className="select-field"
          value={selectedCondition}
          onChange={(e) => setSelectedCondition(e.target.value)}
        >
          {CONDITIONS.map(cond => (
            <option key={cond} value={cond}>{cond}</option>
          ))}
        </select>
      </div>

      {/* Location Filter Input */}
      <div className="input-group">
        <label className="input-label">City / State Location</label>
        <div style={{ position: 'relative' }}>
          <MapPin
            size={16}
            style={{ position: 'absolute', left: '14px', top: '50%', transform: 'translateY(-50%)', color: '#7c3aed' }}
          />
          <input
            type="text"
            className="input-field"
            placeholder="e.g. Bengaluru, Delhi"
            style={{ paddingLeft: '38px', fontSize: '0.88rem' }}
            value={locationQuery}
            onChange={(e) => setLocationQuery(e.target.value)}
          />
        </div>
      </div>

      {/* Price Range Inputs */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px', marginBottom: '16px' }}>
        <div className="input-group" style={{ marginBottom: 0 }}>
          <label className="input-label">Min Price (₹)</label>
          <input
            type="number"
            className="input-field"
            placeholder="e.g. 2000"
            value={minPrice}
            onChange={(e) => setMinPrice(e.target.value)}
          />
        </div>
        <div className="input-group" style={{ marginBottom: 0 }}>
          <label className="input-label">Max Price (₹)</label>
          <input
            type="number"
            className="input-field"
            placeholder="e.g. 50000"
            value={maxPrice}
            onChange={(e) => setMaxPrice(e.target.value)}
          />
        </div>
      </div>

      {/* Sort By Selector */}
      <div className="input-group">
        <label className="input-label">Sort Listings By</label>
        <select
          className="select-field"
          value={sortBy}
          onChange={(e) => setSortBy(e.target.value)}
        >
          <option value="newest">Newest Listings First</option>
          <option value="price_low">Price: Low to High</option>
          <option value="price_high">Price: High to Low</option>
        </select>
      </div>
    </>
  );

  return (
    <div>
      {/* Search Layout Grid: Left Sidebar on Desktop, Top Bar on Mobile */}
      <div className="search-page-layout">
        {/* Desktop Left Sidebar Filter Panel */}
        <aside className="search-sidebar desktop-only-sidebar">
          {renderFilterFields()}
        </aside>

        {/* Main Search Results Area */}
        <main style={{ minWidth: 0 }}>
          {/* Header Title & Mobile Filter Toggle */}
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '16px' }}>
            <div>
              <h2 style={{ fontFamily: 'Outfit, sans-serif', fontSize: '1.4rem', fontWeight: 800, color: '#09090b' }}>
                Search Electronics
              </h2>
              <span style={{ fontSize: '0.85rem', color: '#52525b' }}>
                Showing {filteredProducts.length} items
              </span>
            </div>

            <button
              className="btn-outline mobile-only-filter-btn"
              style={{ padding: '8px 14px', fontSize: '0.85rem', gap: '6px' }}
              onClick={() => setShowFilterDrawer(!showFilterDrawer)}
            >
              <SlidersHorizontal size={16} /> Filters
            </button>
          </div>

          {/* Main Search Text Bar */}
          <div style={{ position: 'relative', marginBottom: '20px' }}>
            <Search
              size={18}
              style={{ position: 'absolute', left: '16px', top: '50%', transform: 'translateY(-50%)', color: '#71717a' }}
            />
            <input
              type="text"
              className="input-field"
              placeholder="Search by model, brand, GPU, RAM, screen size..."
              style={{ paddingLeft: '44px', fontSize: '1rem', borderRadius: '16px' }}
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                style={{ position: 'absolute', right: '14px', top: '50%', transform: 'translateY(-50%)', border: 'none', background: 'none', cursor: 'pointer', color: '#71717a' }}
              >
                <X size={18} />
              </button>
            )}
          </div>

          {/* Mobile Collapsible Filter Drawer */}
          {showFilterDrawer && (
            <div
              className="card-white mobile-filter-drawer"
              style={{
                marginBottom: '20px',
                border: '2px solid #7c3aed',
                backgroundColor: '#ffffff'
              }}
            >
              {renderFilterFields()}
              <button className="btn-purple" onClick={() => setShowFilterDrawer(false)} style={{ width: '100%', marginTop: '12px' }}>
                Apply Filters ({filteredProducts.length} Results)
              </button>
            </div>
          )}

          {/* Results Product Grid */}
          {filteredProducts.length === 0 ? (
            <div className="card-white" style={{ textAlign: 'center', padding: '50px 20px' }}>
              <Search size={44} color="#a1a1aa" style={{ marginBottom: '12px' }} />
              <h4 style={{ fontWeight: 800, fontSize: '1.1rem' }}>No products match your search</h4>
              <p style={{ fontSize: '0.9rem', color: '#71717a', margin: '8px 0 20px 0' }}>
                Try adjusting your search keywords, price range, or category filters.
              </p>
              <button className="btn-outline-purple" onClick={resetFilters}>
                Clear All Filters
              </button>
            </div>
          ) : (
            <div className="product-grid">
              {filteredProducts.map((product) => {
                const isWishlisted = wishlist.includes(product.id);
                const isSold = product.status === 'Sold';

                return (
                  <div
                    key={product.id}
                    className="product-card"
                    onClick={() => navigateTo('product_detail', product)}
                    style={{ cursor: 'pointer' }}
                  >
                    <div className="product-image-container">
                      <img src={product.image} alt={product.name} />
                      <button
                        className={`favorite-btn ${isWishlisted ? 'active' : ''}`}
                        onClick={(e) => {
                          e.stopPropagation();
                          toggleFavorite(product.id);
                        }}
                      >
                        <Heart size={16} fill={isWishlisted ? '#ef4444' : 'none'} color={isWishlisted ? '#ef4444' : '#09090b'} />
                      </button>
                      {isSold && (
                        <div style={{ position: 'absolute', top: '10px', left: '10px', backgroundColor: '#09090b', color: '#ffffff', fontSize: '10px', fontWeight: 800, padding: '4px 8px', borderRadius: '4px' }}>
                          SOLD
                        </div>
                      )}
                      {product.aiPredictedPrice && !isSold && (
                        <div style={{ position: 'absolute', bottom: '8px', left: '8px', backgroundColor: 'rgba(9,9,11,0.85)', backdropFilter: 'blur(4px)', color: '#ffffff', fontSize: '10px', fontWeight: 700, padding: '3px 8px', borderRadius: '6px', display: 'flex', alignItems: 'center', gap: '3px' }}>
                          <Sparkles size={11} color="#a78bfa" />
                          AI: ₹{product.aiPredictedPrice.recommendedPrice?.toLocaleString('en-IN')}
                        </div>
                      )}
                    </div>

                    <div className="product-info">
                      <span style={{ fontSize: '0.72rem', fontWeight: 700, color: '#7c3aed', textTransform: 'uppercase' }}>
                        {product.brand} • {product.condition}
                      </span>
                      <h4 className="product-title">{product.name}</h4>
                      <div style={{ display: 'flex', alignItems: 'baseline', gap: '8px', marginTop: '2px' }}>
                        <span className="product-price">₹{product.sellingPrice?.toLocaleString('en-IN')}</span>
                        {product.originalPrice && (
                          <span style={{ fontSize: '0.78rem', color: '#a1a1aa', textDecoration: 'line-through' }}>
                            ₹{product.originalPrice?.toLocaleString('en-IN')}
                          </span>
                        )}
                      </div>

                      <div className="product-meta">
                        <div style={{ display: 'flex', alignItems: 'center', gap: '3px', color: '#52525b' }}>
                          <MapPin size={12} color="#7c3aed" />
                          <span>{product.sellerCity || 'India'}</span>
                        </div>
                        <span>{product.age || 'Used'}</span>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </main>
      </div>

      <style>{`
        @media (min-width: 900px) {
          .mobile-only-filter-btn { display: none !important; }
          .desktop-only-sidebar { display: block !important; }
        }
        @media (max-width: 899px) {
          .desktop-only-sidebar { display: none !important; }
        }
      `}</style>
    </div>
  );
}
