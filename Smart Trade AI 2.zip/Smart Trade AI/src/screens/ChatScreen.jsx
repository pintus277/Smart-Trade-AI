import React, { useState } from 'react';
import { MessageSquare, Send, Phone, ArrowLeft, Image as ImageIcon, CheckCheck, Sparkles, User } from 'lucide-react';
import { useApp } from '../context/AppContext';

export function ChatScreen() {
  const { messages, currentUser, activeChatThread, setActiveChatThread, sendMessage, navigateTo, products } = useApp();
  const [inputText, setInputText] = useState('');

  // Find active product thread
  const activeProduct = activeChatThread ? products.find(p => p.id === activeChatThread.productId) : null;

  // Filter messages for current conversation thread
  const currentThreadMessages = messages.filter(m =>
    !activeChatThread || (m.productId === activeChatThread.productId)
  );

  // Group messages into conversations list
  const conversationsMap = {};
  messages.forEach(msg => {
    const key = `${msg.productId}_${msg.senderId === currentUser?.id ? msg.receiverId : msg.senderId}`;
    if (!conversationsMap[key]) {
      conversationsMap[key] = msg;
    }
  });
  const conversationList = Object.values(conversationsMap);

  const handleSend = (e) => {
    e.preventDefault();
    if (!inputText.trim() || !activeChatThread) return;

    sendMessage(
      activeChatThread.productId,
      activeChatThread.sellerId,
      activeChatThread.sellerName || 'Seller',
      activeChatThread.productName || 'Electronics Item',
      inputText
    );
    setInputText('');
  };

  // Render Conversation List Items
  const renderConversationsList = () => (
    <div style={{ padding: '16px' }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '16px' }}>
        <h3 style={{ fontFamily: 'Outfit, sans-serif', fontSize: '1.2rem', fontWeight: 800, color: '#09090b' }}>
          Inbox & Messages
        </h3>
        <span style={{ fontSize: '0.8rem', color: '#7c3aed', fontWeight: 700 }}>
          {conversationList.length} Chats
        </span>
      </div>

      {conversationList.length === 0 ? (
        <div style={{ textAlign: 'center', padding: '40px 16px', color: '#71717a' }}>
          <MessageSquare size={36} color="#a1a1aa" style={{ marginBottom: '10px' }} />
          <h4 style={{ fontWeight: 800, fontSize: '0.95rem' }}>No conversations yet</h4>
          <p style={{ fontSize: '0.8rem', margin: '4px 0 16px 0' }}>
            Message sellers on any product listing to start chatting here.
          </p>
          <button className="btn-purple" onClick={() => navigateTo('home')} style={{ fontSize: '0.85rem' }}>
            Browse Marketplace
          </button>
        </div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
          {conversationList.map((conv) => {
            const isSelected = activeChatThread && activeChatThread.productId === conv.productId;
            const otherName = conv.senderId === currentUser?.id ? conv.receiverName : conv.senderName;
            const prod = products.find(p => p.id === conv.productId);

            return (
              <div
                key={conv.id}
                style={{
                  cursor: 'pointer',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '12px',
                  padding: '12px',
                  borderRadius: '14px',
                  backgroundColor: isSelected ? '#f5f3ff' : '#ffffff',
                  border: isSelected ? '1.5px solid #7c3aed' : '1px solid #e2e8f0',
                  transition: 'all 0.2s ease'
                }}
                onClick={() => {
                  navigateTo('chat_thread', {
                    productId: conv.productId,
                    sellerId: conv.senderId === currentUser?.id ? conv.receiverId : conv.senderId,
                    sellerName: otherName,
                    productName: conv.productName,
                    productImage: prod?.image
                  });
                }}
              >
                <div
                  style={{
                    width: '44px',
                    height: '44px',
                    borderRadius: '50%',
                    backgroundColor: '#09090b',
                    color: '#ffffff',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    fontWeight: 800,
                    fontSize: '1rem',
                    fontFamily: 'Outfit, sans-serif',
                    flexShrink: 0
                  }}
                >
                  {otherName ? otherName.charAt(0).toUpperCase() : 'U'}
                </div>

                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
                    <h4 style={{ fontWeight: 800, fontSize: '0.9rem', color: '#09090b', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                      {otherName}
                    </h4>
                    <span style={{ fontSize: '0.7rem', color: '#a1a1aa' }}>
                      {new Date(conv.timestamp).toLocaleDateString([], { month: 'short', day: 'numeric' })}
                    </span>
                  </div>
                  <p style={{ fontSize: '0.75rem', fontWeight: 700, color: '#7c3aed' }}>{conv.productName}</p>
                  <p style={{ fontSize: '0.8rem', color: '#52525b', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis', marginTop: '2px' }}>
                    {conv.message}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );

  // Render Active Thread Content
  const renderThreadContent = () => (
    <div className="chat-thread-container">
      {activeChatThread ? (
        <>
          {/* Chat Thread Header */}
          <div
            style={{
              padding: '14px 20px',
              backgroundColor: '#09090b',
              color: '#ffffff',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
              borderBottom: '1px solid #27272a'
            }}
          >
            <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
              <button
                onClick={() => navigateTo('chat_thread', null)}
                style={{ background: 'none', border: 'none', color: '#ffffff', cursor: 'pointer', display: 'flex', alignItems: 'center' }}
                className="mobile-only-back-chat"
              >
                <ArrowLeft size={20} />
              </button>
              <div>
                <h4 style={{ fontWeight: 800, fontSize: '1rem', fontFamily: 'Outfit, sans-serif', color: '#ffffff' }}>
                  {activeChatThread.sellerName || 'Seller'}
                </h4>
                <span style={{ fontSize: '0.78rem', color: '#a78bfa' }}>
                  Re: {activeChatThread.productName}
                </span>
              </div>
            </div>

            <button
              onClick={() => {
                window.location.href = `tel:${activeProduct?.sellerPhone || '+919876543210'}`;
              }}
              style={{
                backgroundColor: '#7c3aed',
                color: '#ffffff',
                border: 'none',
                borderRadius: '50%',
                width: '38px',
                height: '38px',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                cursor: 'pointer'
              }}
              title="Call Seller"
            >
              <Phone size={18} />
            </button>
          </div>

          {/* Product Context Banner */}
          {activeProduct && (
            <div
              style={{
                backgroundColor: '#ffffff',
                padding: '12px 20px',
                borderBottom: '1px solid #e2e8f0',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                cursor: 'pointer'
              }}
              onClick={() => navigateTo('product_detail', activeProduct)}
            >
              <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                <img
                  src={activeProduct.image}
                  alt={activeProduct.name}
                  style={{ width: '44px', height: '44px', borderRadius: '10px', objectFit: 'cover' }}
                />
                <div>
                  <h5 style={{ fontSize: '0.9rem', fontWeight: 800, color: '#09090b' }}>{activeProduct.name}</h5>
                  <span style={{ fontSize: '0.85rem', fontWeight: 800, color: '#7c3aed' }}>
                    Asking Price: ₹{activeProduct.sellingPrice?.toLocaleString('en-IN')}
                  </span>
                </div>
              </div>
              <span style={{ fontSize: '0.8rem', color: '#7c3aed', fontWeight: 700 }}>View Product Details ›</span>
            </div>
          )}

          {/* Messages Body */}
          <div
            style={{
              flex: 1,
              padding: '20px',
              overflowY: 'auto',
              display: 'flex',
              flexDirection: 'column',
              gap: '14px',
              backgroundColor: '#f8fafc'
            }}
          >
            {currentThreadMessages.length === 0 ? (
              <div style={{ textAlign: 'center', margin: 'auto', color: '#71717a' }}>
                <MessageSquare size={44} color="#7c3aed" style={{ marginBottom: '10px' }} />
                <p style={{ fontWeight: 700, fontSize: '1rem' }}>Start conversation with the seller</p>
                <p style={{ fontSize: '0.85rem', marginTop: '4px' }}>Ask about pickup, price negotiation or condition details.</p>
              </div>
            ) : (
              currentThreadMessages.map((msg) => {
                const isMine = msg.senderId === currentUser?.id || msg.senderName === currentUser?.name;
                return (
                  <div
                    key={msg.id}
                    style={{
                      alignSelf: isMine ? 'flex-end' : 'flex-start',
                      maxWidth: '75%',
                      backgroundColor: isMine ? '#7c3aed' : '#ffffff',
                      color: isMine ? '#ffffff' : '#09090b',
                      padding: '12px 16px',
                      borderRadius: isMine ? '18px 18px 2px 18px' : '18px 18px 18px 2px',
                      boxShadow: '0 2px 8px rgba(0,0,0,0.05)',
                      border: isMine ? 'none' : '1px solid #e2e8f0'
                    }}
                  >
                    <p style={{ fontSize: '0.92rem', lineHeight: '1.45' }}>{msg.message}</p>
                    <div
                      style={{
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'flex-end',
                        gap: '4px',
                        marginTop: '6px',
                        fontSize: '0.7rem',
                        opacity: 0.85
                      }}
                    >
                      <span>{new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                      {isMine && <CheckCheck size={14} />}
                    </div>
                  </div>
                );
              })
            )}
          </div>

          {/* Input Bar */}
          <form
            onSubmit={handleSend}
            style={{
              padding: '14px 20px',
              backgroundColor: '#ffffff',
              borderTop: '1px solid #e2e8f0',
              display: 'flex',
              gap: '12px',
              alignItems: 'center'
            }}
          >
            <input
              type="text"
              className="input-field"
              placeholder="Type your message to seller..."
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              style={{ borderRadius: '24px' }}
            />
            <button
              type="submit"
              className="btn-purple"
              style={{ width: '46px', height: '46px', padding: 0, borderRadius: '50%', flexShrink: 0 }}
            >
              <Send size={20} />
            </button>
          </form>
        </>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', height: '100%', padding: '40px', color: '#71717a' }}>
          <MessageSquare size={54} color="#a78bfa" style={{ marginBottom: '16px' }} />
          <h3 style={{ fontFamily: 'Outfit, sans-serif', fontWeight: 800, fontSize: '1.3rem', color: '#09090b' }}>
            Select a Chat Conversation
          </h3>
          <p style={{ fontSize: '0.9rem', color: '#71717a', textAlign: 'center', marginTop: '6px' }}>
            Choose a conversation from the left sidebar or contact a seller directly from any product page.
          </p>
        </div>
      )}
    </div>
  );

  return (
    <div>
      <div className="chat-web-layout">
        {/* Left Sidebar List */}
        <div className={`chat-sidebar-list ${activeChatThread ? 'hide-on-mobile-when-thread' : ''}`}>
          {renderConversationsList()}
        </div>

        {/* Right Main Thread */}
        <div className={`chat-main-thread ${!activeChatThread ? 'hide-on-mobile-when-no-thread' : ''}`}>
          {renderThreadContent()}
        </div>
      </div>

      <style>{`
        @media (max-width: 767px) {
          .chat-web-layout {
            height: calc(100vh - 170px);
            grid-template-columns: 1fr !important;
          }
          .hide-on-mobile-when-thread {
            display: none !important;
          }
          .hide-on-mobile-when-no-thread {
            display: none !important;
          }
        }
      `}</style>
    </div>
  );
}
