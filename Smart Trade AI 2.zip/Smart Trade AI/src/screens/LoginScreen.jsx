import React, { useState } from 'react';
import { Cpu, ArrowLeft, Mail, Lock, UserPlus, LogIn, ArrowRight } from 'lucide-react';
import { useApp } from '../context/AppContext';

export function LoginScreen() {
  const { loginUser, navigateTo, showToast } = useApp();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!email || !password) {
      showToast('Please enter both Email/Phone and Password', 'error');
      return;
    }
    loginUser(email, password);
  };

  return (
    <div style={{ maxWidth: '480px', margin: '20px auto' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '20px' }}>
        <button onClick={() => navigateTo('home')} className="btn-outline" style={{ padding: '8px 12px', borderRadius: '50%' }}>
          <ArrowLeft size={18} color="#09090b" />
        </button>
        <h2 style={{ fontFamily: 'Outfit, sans-serif', fontSize: '1.3rem', fontWeight: 800, color: '#09090b' }}>
          User Login
        </h2>
      </div>

      <div className="card-white" style={{ boxShadow: '0 10px 30px rgba(0,0,0,0.08)', padding: '28px' }}>
        {/* Brand Badge */}
        <div style={{ textAlign: 'center', marginBottom: '24px' }}>
          <div
            className="brand-icon"
            style={{ margin: '0 auto 14px auto', width: '56px', height: '56px', borderRadius: '16px', boxShadow: '0 8px 20px rgba(124, 58, 237, 0.3)' }}
          >
            <Cpu size={32} />
          </div>
          <h3 style={{ fontFamily: 'Outfit, sans-serif', fontWeight: 800, fontSize: '1.4rem', color: '#09090b' }}>
            Welcome Back
          </h3>
          <p style={{ fontSize: '0.88rem', color: '#52525b', marginTop: '4px' }}>
            Sign in to access your second-hand electronics marketplace, manage listings & chat with buyers.
          </p>
        </div>

        {/* Login Form */}
        <form onSubmit={handleSubmit}>
          <div className="input-group">
            <label className="input-label">Email or Phone Number *</label>
            <div style={{ position: 'relative' }}>
              <Mail size={18} style={{ position: 'absolute', left: '14px', top: '50%', transform: 'translateY(-50%)', color: '#7c3aed' }} />
              <input
                type="text"
                className="input-field"
                placeholder="rahul@smarttrade.ai"
                style={{ paddingLeft: '42px' }}
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
            </div>
          </div>

          <div className="input-group">
            <label className="input-label">Password *</label>
            <div style={{ position: 'relative' }}>
              <Lock size={18} style={{ position: 'absolute', left: '14px', top: '50%', transform: 'translateY(-50%)', color: '#7c3aed' }} />
              <input
                type="password"
                className="input-field"
                placeholder="••••••••"
                style={{ paddingLeft: '42px' }}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
            </div>
          </div>

          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', margin: '12px 0 24px 0', fontSize: '0.85rem' }}>
            <label style={{ display: 'flex', alignItems: 'center', gap: '6px', cursor: 'pointer', color: '#52525b', fontWeight: 600 }}>
              <input type="checkbox" defaultChecked style={{ accentColor: '#7c3aed' }} /> Remember me
            </label>
            <span style={{ color: '#7c3aed', fontWeight: 700, cursor: 'pointer' }}>Forgot Password?</span>
          </div>

          <button type="submit" className="btn-purple" style={{ padding: '14px', fontSize: '1rem', width: '100%', marginBottom: '18px' }}>
            <LogIn size={18} /> Sign In to Account
          </button>
        </form>

        {/* Switch to Register Page */}
        <div
          style={{
            borderTop: '1px solid #e2e8f0',
            paddingTop: '18px',
            marginTop: '10px',
            textAlign: 'center',
            fontSize: '0.88rem',
            color: '#52525b'
          }}
        >
          <span>Don't have a seller account yet? </span>
          <button
            onClick={() => navigateTo('register')}
            style={{
              background: 'none',
              border: 'none',
              color: '#7c3aed',
              fontWeight: 800,
              cursor: 'pointer',
              textDecoration: 'underline',
              display: 'inline-flex',
              alignItems: 'center',
              gap: '4px',
              marginLeft: '4px'
            }}
          >
            Create New Account <ArrowRight size={14} />
          </button>
        </div>
      </div>
    </div>
  );
}
