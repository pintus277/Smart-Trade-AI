import React, { useState } from 'react';
import { Tag, Edit3, Trash2, CheckCircle, Sparkles, ArrowLeft, PlusCircle } from 'lucide-react';
import { useApp } from '../context/AppContext';

export function MyProductsScreen() {
  const { products, currentUser, markAsSold, removeProduct, navigateTo } = useApp();
  const [tab, setTab] = useState('active'); // 'active' | 'sold'

  // Filter listings belonging to current seller
  const myProducts = products.filter(p => p.sellerId === currentUser?.id || p.sellerName === currentUser?.name);
  const activeProducts = myProducts.filter(p => p.status !== 'Sold');
  const soldProducts = myProducts.filter(p => p.status === 'Sold');

  const displayedListings = tab === 'active' ? activeProducts : soldProducts;

  return (
    <div>
      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '20px' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
          <button onClick={() => navigateTo('profile')} className="btn-outline" style={{ padding: '8px 12px', borderRadius: '50%' }}>
            <ArrowLeft size={18} color="#09090b" />
          </button>
          <h2 style={{ fontFamily: 'Outfit, sans-serif', fontSize: '1.4rem', fontWeight: 800, color: '#09090b' }}>
            My Electronics Listings
          </h2>
        </div>

        <button className="btn-purple" onClick={() => navigateTo('sell')} style={{ fontSize: '0.85rem' }}>
          <PlusCircle size={16} /> Add New Listing
        </button>
      </div>

      {/* Tabs */}
      <div style={{ display: 'flex', gap: '10px', marginBottom: '24px', borderBottom: '1px solid #e2e8f0', paddingBottom: '10px' }}>
        <button
          className={`category-chip ${tab === 'active' ? 'active' : ''}`}
          onClick={() => setTab('active')}
        >
          Active Listings ({activeProducts.length})
        </button>
        <button
          className={`category-chip ${tab === 'sold' ? 'active' : ''}`}
          onClick={() => setTab('sold')}
        >
          Sold Products ({soldProducts.length})
        </button>
      </div>

      {/* Product List */}
      {displayedListings.length === 0 ? (
        <div className="card-white" style={{ textAlign: 'center', padding: '48px 20px' }}>
          <Tag size={44} color="#a1a1aa" style={{ marginBottom: '12px' }} />
          <h4 style={{ fontWeight: 800, fontSize: '1.1rem' }}>No {tab} listings</h4>
          <p style={{ fontSize: '0.9rem', color: '#71717a', margin: '6px 0 20px 0' }}>
            {tab === 'active' ? "You don't have any active product listings yet." : "You haven't marked any items as sold yet."}
          </p>
          <button className="btn-purple" onClick={() => navigateTo('sell')}>
            <PlusCircle size={18} /> Add New Listing
          </button>
        </div>
      ) : (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(320px, 1fr))', gap: '16px' }}>
          {displayedListings.map((product) => (
            <div key={product.id} className="card-white" style={{ display: 'flex', gap: '14px', padding: '16px', alignItems: 'center' }}>
              <img
                src={product.image}
                alt={product.name}
                style={{ width: '90px', height: '90px', borderRadius: '12px', objectFit: 'cover' }}
              />
              <div style={{ flex: 1, minWidth: 0 }}>
                <span className="ai-badge" style={{ fontSize: '0.7rem', padding: '2px 8px' }}>
                  {product.category}
                </span>
                <h4 style={{ fontSize: '0.95rem', fontWeight: 800, color: '#09090b', margin: '4px 0', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                  {product.name}
                </h4>
                <div style={{ fontSize: '1.05rem', fontWeight: 800, color: '#7c3aed', fontFamily: 'Outfit, sans-serif' }}>
                  Asking: ₹{product.sellingPrice?.toLocaleString('en-IN')}
                </div>

                <div style={{ display: 'flex', gap: '8px', marginTop: '10px' }}>
                  {product.status !== 'Sold' && (
                    <button
                      onClick={() => markAsSold(product.id)}
                      style={{
                        backgroundColor: '#10b981',
                        color: '#ffffff',
                        border: 'none',
                        padding: '6px 12px',
                        borderRadius: '8px',
                        fontSize: '0.78rem',
                        fontWeight: 700,
                        cursor: 'pointer',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '4px'
                      }}
                    >
                      <CheckCircle size={14} /> Mark Sold
                    </button>
                  )}
                  <button
                    onClick={() => removeProduct(product.id)}
                    style={{
                      backgroundColor: '#ef4444',
                      color: '#ffffff',
                      border: 'none',
                      padding: '6px 12px',
                      borderRadius: '8px',
                      fontSize: '0.78rem',
                      fontWeight: 700,
                      cursor: 'pointer',
                      display: 'flex',
                      alignItems: 'center',
                      gap: '4px'
                    }}
                  >
                    <Trash2 size={14} /> Delete
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
