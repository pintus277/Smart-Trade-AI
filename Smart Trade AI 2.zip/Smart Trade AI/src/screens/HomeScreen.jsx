import React from 'react';
import { Search, Sparkles, SlidersHorizontal, MapPin, Heart, ArrowRight, ShieldCheck, Tag, PlusCircle, TrendingUp, Cpu, CheckCircle2 } from 'lucide-react';
import { useApp } from '../context/AppContext';

const CATEGORIES = [
  'All',
  'Smartphones',
  'Laptops',
  'PC Components',
  'Graphics Cards',
  'RAM',
  'Storage',
  'Accessories',
  'Audio Devices',
  'Cameras',
  'Other Electronics'
];

export function HomeScreen() {
  const {
    products,
    wishlist,
    selectedCategory,
    setSelectedCategory,
    searchQuery,
    setSearchQuery,
    navigateTo,
    toggleFavorite
  } = useApp();

  const filteredProducts = products.filter(product => {
    const matchesCategory = selectedCategory === 'All' || product.category === selectedCategory;
    const matchesSearch = !searchQuery || 
      product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      product.brand.toLowerCase().includes(searchQuery.toLowerCase()) ||
      product.model.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <div>
      {/* Mobile-Only Search Input Bar (Header Search Bar shows on Desktop) */}
      <div style={{ display: 'flex', gap: '10px', marginBottom: '20px' }} className="mobile-search-wrapper">
        <div style={{ position: 'relative', flex: 1 }}>
          <Search
            size={18}
            style={{ position: 'absolute', left: '14px', top: '50%', transform: 'translateY(-50%)', color: '#71717a' }}
          />
          <input
            type="text"
            className="input-field"
            placeholder="Search phones, laptops, GPUs, RAM..."
            style={{ paddingLeft: '42px', borderRadius: '14px' }}
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter') navigateTo('search');
            }}
          />
        </div>
        <button
          className="btn-black"
          style={{ width: 'auto', padding: '0 16px', borderRadius: '14px' }}
          onClick={() => navigateTo('search')}
        >
          <SlidersHorizontal size={18} />
        </button>
      </div>

      {/* AI Hero Banner - Expanded Desktop Friendly Layout */}
      <div
        style={{
          background: 'linear-gradient(135deg, #09090b 0%, #18181b 50%, #27272a 100%)',
          color: '#ffffff',
          borderRadius: '24px',
          padding: '32px 28px',
          marginBottom: '28px',
          position: 'relative',
          overflow: 'hidden',
          boxShadow: '0 15px 35px rgba(0,0,0,0.25)',
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))',
          gap: '24px',
          alignItems: 'center'
        }}
      >
        <div style={{ zIndex: 2 }}>
          <div className="ai-badge" style={{ backgroundColor: 'rgba(124, 58, 237, 0.25)', color: '#a78bfa', borderColor: '#7c3aed', marginBottom: '14px' }}>
            <Sparkles size={14} /> Smart AI Price Prediction Engine
          </div>
          <h1 style={{ fontFamily: 'Outfit, sans-serif', fontSize: '1.85rem', fontWeight: 800, marginBottom: '10px', lineHeight: 1.25 }}>
            Buy & Sell Second-Hand Electronics at Fair AI Resale Values
          </h1>
          <p style={{ fontSize: '0.95rem', color: '#a1a1aa', marginBottom: '22px', maxWidth: '540px', lineHeight: 1.6 }}>
            Instant price estimation calculated using machine learning from specs, age, condition & brand retention curves. Verified electronic photo verification included!
          </p>
          <div style={{ display: 'flex', gap: '12px', flexWrap: 'wrap' }}>
            <button
              className="btn-purple"
              style={{ padding: '12px 22px', fontSize: '0.95rem' }}
              onClick={() => navigateTo('sell')}
            >
              <PlusCircle size={18} /> List Item & Predict Price
            </button>
            <button
              className="btn-black"
              style={{ padding: '12px 20px', fontSize: '0.95rem', backgroundColor: 'rgba(255,255,255,0.1)', border: '1px solid rgba(255,255,255,0.2)' }}
              onClick={() => navigateTo('search')}
            >
              Explore All Listings <ArrowRight size={16} />
            </button>
          </div>
        </div>

        {/* Feature Highlights Mini Card on Desktop */}
        <div
          style={{
            backgroundColor: 'rgba(255, 255, 255, 0.05)',
            backdropFilter: 'blur(12px)',
            border: '1px solid rgba(255, 255, 255, 0.12)',
            borderRadius: '20px',
            padding: '20px',
            zIndex: 2,
            display: 'flex',
            flexDirection: 'column',
            gap: '14px'
          }}
        >
          <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
            <div style={{ width: '40px', height: '40px', borderRadius: '12px', backgroundColor: '#7c3aed', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <TrendingUp size={20} color="#ffffff" />
            </div>
            <div>
              <h4 style={{ fontSize: '0.95rem', fontWeight: 800, color: '#ffffff' }}>94%+ Valuation Accuracy</h4>
              <p style={{ fontSize: '0.8rem', color: '#a1a1aa' }}>Smart depreciation algorithms</p>
            </div>
          </div>

          <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
            <div style={{ width: '40px', height: '40px', borderRadius: '12px', backgroundColor: '#10b981', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <ShieldCheck size={20} color="#ffffff" />
            </div>
            <div>
              <h4 style={{ fontSize: '0.95rem', fontWeight: 800, color: '#ffffff' }}>Verified Hardware Check</h4>
              <p style={{ fontSize: '0.8rem', color: '#a1a1aa' }}>Automated AI image verification</p>
            </div>
          </div>
        </div>

        <div
          style={{
            position: 'absolute',
            right: '-30px',
            top: '-30px',
            width: '240px',
            height: '240px',
            borderRadius: '50%',
            background: 'radial-gradient(circle, rgba(124,58,237,0.35) 0%, rgba(0,0,0,0) 70%)',
            pointerEvents: 'none'
          }}
        />
      </div>

      {/* Categories Horizontal Carousel / Filter Bar */}
      <div style={{ marginBottom: '28px' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '14px' }}>
          <h3 style={{ fontFamily: 'Outfit, sans-serif', fontSize: '1.2rem', fontWeight: 800, color: '#09090b' }}>
            Browse Categories
          </h3>
          <span style={{ fontSize: '0.85rem', fontWeight: 700, color: '#7c3aed', cursor: 'pointer' }} onClick={() => navigateTo('search')}>
            View All Categories ›
          </span>
        </div>
        <div
          style={{
            display: 'flex',
            gap: '10px',
            overflowX: 'auto',
            paddingBottom: '8px',
            scrollbarWidth: 'none'
          }}
        >
          {CATEGORIES.map((cat) => (
            <button
              key={cat}
              className={`category-chip ${selectedCategory === cat ? 'active' : ''}`}
              onClick={() => setSelectedCategory(cat)}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Featured Electronics Marketplace Section */}
      <div style={{ marginBottom: '32px' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
          <div>
            <h3 style={{ fontFamily: 'Outfit, sans-serif', fontSize: '1.2rem', fontWeight: 800, color: '#09090b' }}>
              Second-Hand Electronics Marketplace
            </h3>
            <p style={{ fontSize: '0.85rem', color: '#71717a' }}>Verified listings across India with AI market price badges</p>
          </div>
          <span style={{ fontSize: '0.88rem', fontWeight: 700, color: '#52525b' }}>{filteredProducts.length} items available</span>
        </div>

        {filteredProducts.length === 0 ? (
          <div className="card-white" style={{ textAlign: 'center', padding: '48px 20px' }}>
            <Tag size={40} color="#a1a1aa" style={{ marginBottom: '12px' }} />
            <h4 style={{ fontSize: '1.1rem', fontWeight: 800, color: '#09090b' }}>No products found</h4>
            <p style={{ fontSize: '0.9rem', color: '#71717a', marginBottom: '20px' }}>
              No items match category "{selectedCategory}". Be the first to list one on Smart Trade AI!
            </p>
            <button className="btn-purple" style={{ width: 'auto' }} onClick={() => navigateTo('sell')}>
              List a Product Now
            </button>
          </div>
        ) : (
          <div className="product-grid">
            {filteredProducts.map((product) => {
              const isWishlisted = wishlist.includes(product.id);
              const isSold = product.status === 'Sold';

              return (
                <div
                  key={product.id}
                  className="product-card"
                  onClick={() => navigateTo('product_detail', product)}
                  style={{ cursor: 'pointer' }}
                >
                  <div className="product-image-container">
                    <img src={product.image} alt={product.name} />
                    <button
                      className={`favorite-btn ${isWishlisted ? 'active' : ''}`}
                      onClick={(e) => {
                        e.stopPropagation();
                        toggleFavorite(product.id);
                      }}
                      title="Wishlist"
                    >
                      <Heart size={16} fill={isWishlisted ? '#ef4444' : 'none'} color={isWishlisted ? '#ef4444' : '#09090b'} />
                    </button>
                    {isSold && (
                      <div
                        style={{
                          position: 'absolute',
                          top: '10px',
                          left: '10px',
                          backgroundColor: '#09090b',
                          color: '#ffffff',
                          fontSize: '11px',
                          fontWeight: 800,
                          padding: '4px 10px',
                          borderRadius: '6px'
                        }}
                      >
                        SOLD
                      </div>
                    )}
                    {product.aiPredictedPrice && !isSold && (
                      <div
                        style={{
                          position: 'absolute',
                          bottom: '8px',
                          left: '8px',
                          backgroundColor: 'rgba(9, 9, 11, 0.88)',
                          backdropFilter: 'blur(6px)',
                          color: '#ffffff',
                          fontSize: '11px',
                          fontWeight: 700,
                          padding: '3px 8px',
                          borderRadius: '8px',
                          display: 'flex',
                          alignItems: 'center',
                          gap: '4px'
                        }}
                      >
                        <Sparkles size={12} color="#a78bfa" />
                        AI: ₹{product.aiPredictedPrice.recommendedPrice?.toLocaleString('en-IN')}
                      </div>
                    )}
                  </div>

                  <div className="product-info">
                    <span style={{ fontSize: '0.72rem', fontWeight: 700, color: '#7c3aed', textTransform: 'uppercase' }}>
                      {product.brand} • {product.condition}
                    </span>
                    <h4 className="product-title">{product.name}</h4>
                    <div style={{ display: 'flex', alignItems: 'baseline', gap: '8px', marginTop: '2px' }}>
                      <span className="product-price">₹{product.sellingPrice?.toLocaleString('en-IN')}</span>
                      {product.originalPrice && (
                        <span style={{ fontSize: '0.8rem', color: '#a1a1aa', textDecoration: 'line-through' }}>
                          ₹{product.originalPrice?.toLocaleString('en-IN')}
                        </span>
                      )}
                    </div>

                    <div className="product-meta">
                      <div style={{ display: 'flex', alignItems: 'center', gap: '4px', color: '#52525b' }}>
                        <MapPin size={12} color="#7c3aed" />
                        <span>{product.sellerCity || 'India'}</span>
                      </div>
                      <span>{product.age || 'Used'}</span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
