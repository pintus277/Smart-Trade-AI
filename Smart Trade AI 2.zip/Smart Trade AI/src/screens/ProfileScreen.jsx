import React, { useState } from 'react';
import { User, MapPin, Phone, Mail, Package, Heart, MessageSquare, Settings, LogOut, Edit3, ShieldCheck } from 'lucide-react';
import { useApp } from '../context/AppContext';

export function ProfileScreen() {
  const { currentUser, logoutUser, navigateTo, products, wishlist } = useApp();

  const [isEditing, setIsEditing] = useState(false);
  const [name, setName] = useState(currentUser?.name || 'Rahul Sharma');
  const [email, setEmail] = useState(currentUser?.email || 'rahul@smarttrade.ai');
  const [phone, setPhone] = useState(currentUser?.phone || '+91 98765 43210');
  const [address, setAddress] = useState(currentUser?.address || '104, Green Glen Layout');
  const [city, setCity] = useState(currentUser?.city || 'Bengaluru');
  const [state, setState] = useState(currentUser?.state || 'Karnataka');
  const [pincode, setPincode] = useState(currentUser?.pincode || '560103');

  if (!currentUser) {
    return (
      <div style={{ maxWidth: '500px', margin: '40px auto', textAlign: 'center' }}>
        <div className="card-white" style={{ padding: '40px 24px' }}>
          <div style={{ width: '72px', height: '72px', borderRadius: '50%', backgroundColor: '#f5f3ff', color: '#7c3aed', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 20px auto' }}>
            <User size={36} />
          </div>
          <h3 style={{ fontFamily: 'Outfit, sans-serif', fontSize: '1.4rem', fontWeight: 800, color: '#09090b' }}>
            No Active Profile
          </h3>
          <p style={{ fontSize: '0.9rem', color: '#52525b', margin: '10px 0 28px 0', lineHeight: 1.6 }}>
            Create your custom seller profile by registering an account, or sign in if you already have one.
          </p>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
            <button className="btn-purple" onClick={() => navigateTo('register')}>
              ✨ Register New Seller Account
            </button>
            <button className="btn-black" onClick={() => navigateTo('login')}>
              Sign In to Existing Account
            </button>
          </div>
        </div>
      </div>
    );
  }

  const myProductsCount = products.filter(p => p.sellerId === currentUser.id || p.sellerName === currentUser.name).length;

  return (
    <div style={{ maxWidth: '900px', margin: '0 auto' }}>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))', gap: '24px' }}>
        {/* Profile Card Left */}
        <div className="card-white" style={{ textAlign: 'center', position: 'relative' }}>
          <div
            style={{
              width: '84px',
              height: '84px',
              borderRadius: '50%',
              backgroundColor: '#09090b',
              color: '#ffffff',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              fontSize: '2.2rem',
              fontWeight: 800,
              margin: '0 auto 14px auto',
              border: '3px solid #7c3aed',
              fontFamily: 'Outfit, sans-serif'
            }}
          >
            {currentUser.name ? currentUser.name.charAt(0).toUpperCase() : 'U'}
          </div>

          <h3 style={{ fontFamily: 'Outfit, sans-serif', fontSize: '1.35rem', fontWeight: 800, color: '#09090b' }}>
            {currentUser.name}
          </h3>
          <span className="ai-badge" style={{ marginTop: '6px' }}>
            Verified Marketplace Seller
          </span>

          <div style={{ marginTop: '16px', fontSize: '0.9rem', color: '#52525b', textAlign: 'left', borderTop: '1px dashed #e2e8f0', paddingTop: '16px' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '8px' }}>
              <Mail size={16} color="#7c3aed" /> <span>{currentUser.email}</span>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '8px' }}>
              <Phone size={16} color="#7c3aed" /> <span>{currentUser.phone}</span>
            </div>
            <div style={{ display: 'flex', alignItems: 'flex-start', gap: '10px' }}>
              <MapPin size={16} color="#7c3aed" style={{ marginTop: '2px' }} />
              <span>{currentUser.address}, {currentUser.city}, {currentUser.state} - {currentUser.pincode}</span>
            </div>
          </div>

          <button
            onClick={() => setIsEditing(!isEditing)}
            style={{
              marginTop: '18px',
              width: '100%',
              padding: '10px',
              backgroundColor: '#f1f5f9',
              border: 'none',
              borderRadius: '12px',
              fontWeight: 700,
              fontSize: '0.85rem',
              color: '#09090b',
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              gap: '8px'
            }}
          >
            <Edit3 size={16} /> {isEditing ? 'Close Edit Panel' : 'Edit Profile Information'}
          </button>
        </div>

        {/* Right Menu Options List or Edit Form */}
        <div>
          {isEditing ? (
            <div className="card-white" style={{ border: '1.5px solid #7c3aed' }}>
              <h4 style={{ fontWeight: 800, fontSize: '1.1rem', marginBottom: '16px' }}>Update Profile Details</h4>
              <div className="input-group">
                <label className="input-label">Full Name</label>
                <input type="text" className="input-field" value={name} onChange={(e) => setName(e.target.value)} />
              </div>
              <div className="input-group">
                <label className="input-label">Phone Number</label>
                <input type="text" className="input-field" value={phone} onChange={(e) => setPhone(e.target.value)} />
              </div>
              <div className="input-group">
                <label className="input-label">Address</label>
                <input type="text" className="input-field" value={address} onChange={(e) => setAddress(e.target.value)} />
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '10px' }}>
                <div className="input-group">
                  <label className="input-label">City</label>
                  <input type="text" className="input-field" value={city} onChange={(e) => setCity(e.target.value)} />
                </div>
                <div className="input-group">
                  <label className="input-label">State</label>
                  <input type="text" className="input-field" value={state} onChange={(e) => setState(e.target.value)} />
                </div>
                <div className="input-group">
                  <label className="input-label">Pincode</label>
                  <input type="text" className="input-field" value={pincode} onChange={(e) => setPincode(e.target.value)} />
                </div>
              </div>
              <button className="btn-purple" onClick={() => setIsEditing(false)} style={{ marginTop: '10px', width: '100%' }}>
                Save Profile Changes
              </button>
            </div>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
              <button
                className="card-white"
                onClick={() => navigateTo('my_products')}
                style={{ cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '18px' }}
              >
                <div style={{ display: 'flex', alignItems: 'center', gap: '14px' }}>
                  <div style={{ width: '42px', height: '42px', borderRadius: '12px', backgroundColor: '#f5f3ff', color: '#7c3aed', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                    <Package size={22} />
                  </div>
                  <div style={{ textAlign: 'left' }}>
                    <h4 style={{ fontWeight: 800, fontSize: '1rem', color: '#09090b' }}>My Products</h4>
                    <p style={{ fontSize: '0.8rem', color: '#71717a' }}>Manage active listings & sold electronics</p>
                  </div>
                </div>
                <span style={{ fontWeight: 800, fontSize: '0.9rem', color: '#7c3aed' }}>{myProductsCount} Items ›</span>
              </button>

              <button
                className="card-white"
                onClick={() => navigateTo('wishlist')}
                style={{ cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '18px' }}
              >
                <div style={{ display: 'flex', alignItems: 'center', gap: '14px' }}>
                  <div style={{ width: '42px', height: '42px', borderRadius: '12px', backgroundColor: '#fef2f2', color: '#ef4444', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                    <Heart size={22} />
                  </div>
                  <div style={{ textAlign: 'left' }}>
                    <h4 style={{ fontWeight: 800, fontSize: '1rem', color: '#09090b' }}>Saved Wishlist</h4>
                    <p style={{ fontSize: '0.8rem', color: '#71717a' }}>Your bookmarked electronics</p>
                  </div>
                </div>
                <span style={{ fontWeight: 800, fontSize: '0.9rem', color: '#ef4444' }}>{wishlist.length} Saved ›</span>
              </button>

              <button
                className="card-white"
                onClick={() => navigateTo('messages')}
                style={{ cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '18px' }}
              >
                <div style={{ display: 'flex', alignItems: 'center', gap: '14px' }}>
                  <div style={{ width: '42px', height: '42px', borderRadius: '12px', backgroundColor: '#f8fafc', color: '#09090b', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                    <MessageSquare size={22} />
                  </div>
                  <div style={{ textAlign: 'left' }}>
                    <h4 style={{ fontWeight: 800, fontSize: '1rem', color: '#09090b' }}>Messages & Inbox</h4>
                    <p style={{ fontSize: '0.8rem', color: '#71717a' }}>Chat with buyers & sellers</p>
                  </div>
                </div>
                <span style={{ fontWeight: 800, fontSize: '0.9rem', color: '#09090b' }}>View Inbox ›</span>
              </button>

              <button
                className="card-white"
                onClick={logoutUser}
                style={{ cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '14px', padding: '18px', color: '#ef4444' }}
              >
                <div style={{ width: '42px', height: '42px', borderRadius: '12px', backgroundColor: '#fef2f2', color: '#ef4444', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                  <LogOut size={22} />
                </div>
                <h4 style={{ fontWeight: 800, fontSize: '1rem' }}>Logout Account</h4>
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
