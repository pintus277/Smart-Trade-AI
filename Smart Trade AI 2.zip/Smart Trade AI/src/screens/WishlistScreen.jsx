import React from 'react';
import { Heart, MapPin, Sparkles, ArrowLeft } from 'lucide-react';
import { useApp } from '../context/AppContext';

export function WishlistScreen() {
  const { wishlist, products, toggleFavorite, navigateTo } = useApp();

  const savedProducts = products.filter(p => wishlist.includes(p.id));

  return (
    <div>
      <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '24px' }}>
        <button onClick={() => navigateTo('home')} className="btn-outline" style={{ padding: '8px 12px', borderRadius: '50%' }}>
          <ArrowLeft size={18} color="#09090b" />
        </button>
        <div>
          <h2 style={{ fontFamily: 'Outfit, sans-serif', fontSize: '1.4rem', fontWeight: 800, color: '#09090b' }}>
            My Saved Wishlist ♥ ({savedProducts.length})
          </h2>
          <p style={{ fontSize: '0.85rem', color: '#52525b' }}>Bookmarked electronics listings for easy access</p>
        </div>
      </div>

      {savedProducts.length === 0 ? (
        <div className="card-white" style={{ textAlign: 'center', padding: '50px 20px' }}>
          <Heart size={48} color="#a1a1aa" style={{ marginBottom: '12px' }} />
          <h4 style={{ fontWeight: 800, fontSize: '1.1rem' }}>Your wishlist is empty</h4>
          <p style={{ fontSize: '0.9rem', color: '#71717a', margin: '6px 0 20px 0' }}>
            Tap the heart icon on any product listing to bookmark it here.
          </p>
          <button className="btn-purple" onClick={() => navigateTo('home')}>
            Browse Products Marketplace
          </button>
        </div>
      ) : (
        <div className="product-grid">
          {savedProducts.map((product) => (
            <div
              key={product.id}
              className="product-card"
              onClick={() => navigateTo('product_detail', product)}
              style={{ cursor: 'pointer' }}
            >
              <div className="product-image-container">
                <img src={product.image} alt={product.name} />
                <button
                  className="favorite-btn active"
                  onClick={(e) => {
                    e.stopPropagation();
                    toggleFavorite(product.id);
                  }}
                >
                  <Heart size={16} fill="#ef4444" color="#ef4444" />
                </button>
              </div>

              <div className="product-info">
                <span style={{ fontSize: '0.72rem', fontWeight: 700, color: '#7c3aed', textTransform: 'uppercase' }}>
                  {product.brand} • {product.condition}
                </span>
                <h4 className="product-title">{product.name}</h4>
                <div style={{ display: 'flex', alignItems: 'baseline', gap: '6px', marginTop: '2px' }}>
                  <span className="product-price">₹{product.sellingPrice?.toLocaleString('en-IN')}</span>
                </div>

                <div className="product-meta">
                  <div style={{ display: 'flex', alignItems: 'center', gap: '3px', color: '#52525b' }}>
                    <MapPin size={12} color="#7c3aed" />
                    <span>{product.sellerCity || 'India'}</span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
