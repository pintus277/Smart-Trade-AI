import React, { useState } from 'react';
import { Cpu, ArrowLeft, User, Mail, Phone, Lock, MapPin, UserPlus, ArrowRight } from 'lucide-react';
import { useApp } from '../context/AppContext';

export function RegisterScreen() {
  const { registerUser, navigateTo, showToast } = useApp();

  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [address, setAddress] = useState('');
  const [city, setCity] = useState('Bengaluru');
  const [state, setState] = useState('Karnataka');
  const [pincode, setPincode] = useState('560001');

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!name || !email || !phone || !password) {
      showToast('Please fill in all required fields marked with *', 'error');
      return;
    }
    if (password !== confirmPassword) {
      showToast('Passwords do not match!', 'error');
      return;
    }

    registerUser({
      name,
      email,
      phone,
      password,
      address,
      city,
      state,
      pincode
    });
  };

  return (
    <div style={{ maxWidth: '640px', margin: '20px auto' }}>
      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '20px' }}>
        <button onClick={() => navigateTo('home')} className="btn-outline" style={{ padding: '8px 12px', borderRadius: '50%' }}>
          <ArrowLeft size={18} color="#09090b" />
        </button>
        <h2 style={{ fontFamily: 'Outfit, sans-serif', fontSize: '1.3rem', fontWeight: 800, color: '#09090b' }}>
          Seller Account Registration
        </h2>
      </div>

      <div className="card-white" style={{ boxShadow: '0 10px 30px rgba(0,0,0,0.08)', padding: '28px' }}>
        {/* Brand Header */}
        <div style={{ textAlign: 'center', marginBottom: '24px' }}>
          <div
            className="brand-icon"
            style={{ margin: '0 auto 12px auto', width: '56px', height: '56px', borderRadius: '16px', backgroundColor: '#7c3aed' }}
          >
            <UserPlus size={28} />
          </div>
          <h3 style={{ fontFamily: 'Outfit, sans-serif', fontWeight: 800, fontSize: '1.4rem', color: '#09090b' }}>
            Create Seller Account
          </h3>
          <p style={{ fontSize: '0.88rem', color: '#52525b', marginTop: '4px' }}>
            Join Smart Trade AI to list gadgets, run AI price valuations & buy electronics.
          </p>
        </div>

        {/* Registration Form */}
        <form onSubmit={handleSubmit}>
          <div className="input-group">
            <label className="input-label">Full Name *</label>
            <div style={{ position: 'relative' }}>
              <User size={18} style={{ position: 'absolute', left: '14px', top: '50%', transform: 'translateY(-50%)', color: '#7c3aed' }} />
              <input
                type="text"
                className="input-field"
                placeholder="e.g. Rahul Sharma"
                style={{ paddingLeft: '42px' }}
                value={name}
                onChange={(e) => setName(e.target.value)}
              />
            </div>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: '14px' }}>
            <div className="input-group">
              <label className="input-label">Email Address *</label>
              <input
                type="email"
                className="input-field"
                placeholder="name@email.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
            </div>
            <div className="input-group">
              <label className="input-label">Phone Number *</label>
              <input
                type="text"
                className="input-field"
                placeholder="+91 98765 43210"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
              />
            </div>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: '14px' }}>
            <div className="input-group">
              <label className="input-label">Password *</label>
              <input
                type="password"
                className="input-field"
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
            </div>
            <div className="input-group">
              <label className="input-label">Confirm Password *</label>
              <input
                type="password"
                className="input-field"
                placeholder="••••••••"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
              />
            </div>
          </div>

          <div className="input-group">
            <label className="input-label">Full Address / Street *</label>
            <div style={{ position: 'relative' }}>
              <MapPin size={18} style={{ position: 'absolute', left: '14px', top: '50%', transform: 'translateY(-50%)', color: '#7c3aed' }} />
              <input
                type="text"
                className="input-field"
                placeholder="House / Flat No, Street name, Area"
                style={{ paddingLeft: '42px' }}
                value={address}
                onChange={(e) => setAddress(e.target.value)}
              />
            </div>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '10px' }}>
            <div className="input-group">
              <label className="input-label">City *</label>
              <input
                type="text"
                className="input-field"
                value={city}
                onChange={(e) => setCity(e.target.value)}
              />
            </div>
            <div className="input-group">
              <label className="input-label">State *</label>
              <input
                type="text"
                className="input-field"
                value={state}
                onChange={(e) => setState(e.target.value)}
              />
            </div>
            <div className="input-group">
              <label className="input-label">Pincode *</label>
              <input
                type="text"
                className="input-field"
                value={pincode}
                onChange={(e) => setPincode(e.target.value)}
              />
            </div>
          </div>

          <button type="submit" className="btn-purple" style={{ margin: '16px 0 18px 0', padding: '14px', fontSize: '1rem', width: '100%' }}>
            Complete Registration & Launch <ArrowRight size={18} />
          </button>
        </form>

        {/* Switch to Login Page */}
        <div
          style={{
            borderTop: '1px solid #e2e8f0',
            paddingTop: '16px',
            textAlign: 'center',
            fontSize: '0.88rem',
            color: '#52525b'
          }}
        >
          <span>Already have an account? </span>
          <button
            onClick={() => navigateTo('login')}
            style={{
              background: 'none',
              border: 'none',
              color: '#7c3aed',
              fontWeight: 800,
              cursor: 'pointer',
              textDecoration: 'underline',
              marginLeft: '4px'
            }}
          >
            Go to Login Page
          </button>
        </div>
      </div>
    </div>
  );
}
