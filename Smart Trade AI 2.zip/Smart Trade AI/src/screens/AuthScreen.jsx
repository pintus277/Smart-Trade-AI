import React, { useState } from 'react';
import { Cpu, ArrowLeft, Lock, Mail, Phone, MapPin, User, CheckCircle } from 'lucide-react';
import { useApp } from '../context/AppContext';

export function AuthScreen() {
  const { loginUser, registerUser, navigateTo, showToast } = useApp();

  const [mode, setMode] = useState('login'); // 'login' | 'register'

  // Login state
  const [loginEmail, setLoginEmail] = useState('rahul@smarttrade.ai');
  const [loginPassword, setLoginPassword] = useState('password123');

  // Register state
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [address, setAddress] = useState('');
  const [city, setCity] = useState('Bengaluru');
  const [state, setState] = useState('Karnataka');
  const [pincode, setPincode] = useState('560001');

  const handleLoginSubmit = (e) => {
    e.preventDefault();
    if (!loginEmail || !loginPassword) {
      showToast('Please enter your email and password', 'error');
      return;
    }
    loginUser(loginEmail, loginPassword);
  };

  const handleRegisterSubmit = (e) => {
    e.preventDefault();
    if (!name || !email || !phone || !password) {
      showToast('Please fill in all required fields', 'error');
      return;
    }
    if (password !== confirmPassword) {
      showToast('Passwords do not match!', 'error');
      return;
    }

    registerUser({
      name,
      email,
      phone,
      password,
      address,
      city,
      state,
      pincode
    });
  };

  return (
    <div style={{ padding: '16px' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '20px' }}>
        <button onClick={() => navigateTo('home')} style={{ background: 'none', border: 'none', cursor: 'pointer' }}>
          <ArrowLeft size={20} color="#09090b" />
        </button>
        <h2 style={{ fontFamily: 'Outfit, sans-serif', fontSize: '1.25rem', fontWeight: 800, color: '#09090b' }}>
          {mode === 'login' ? 'User Login' : 'Create Account'}
        </h2>
      </div>

      <div className="card-white">
        {/* Toggle Mode Tabs */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px', marginBottom: '20px', backgroundColor: '#f1f5f9', padding: '4px', borderRadius: '14px' }}>
          <button
            onClick={() => setMode('login')}
            style={{
              padding: '10px',
              borderRadius: '10px',
              border: 'none',
              fontWeight: 800,
              fontSize: '0.9rem',
              cursor: 'pointer',
              backgroundColor: mode === 'login' ? '#09090b' : 'transparent',
              color: mode === 'login' ? '#ffffff' : '#52525b',
              transition: 'all 0.2s ease'
            }}
          >
            Login
          </button>
          <button
            onClick={() => setMode('register')}
            style={{
              padding: '10px',
              borderRadius: '10px',
              border: 'none',
              fontWeight: 800,
              fontSize: '0.9rem',
              cursor: 'pointer',
              backgroundColor: mode === 'register' ? '#7c3aed' : 'transparent',
              color: mode === 'register' ? '#ffffff' : '#52525b',
              transition: 'all 0.2s ease'
            }}
          >
            Register Account
          </button>
        </div>

        <div style={{ textAlign: 'center', marginBottom: '20px' }}>
          <div className="brand-icon" style={{ margin: '0 auto 10px auto', width: '48px', height: '48px', borderRadius: '14px' }}>
            <Cpu size={28} />
          </div>
          <h3 style={{ fontFamily: 'Outfit, sans-serif', fontWeight: 800, fontSize: '1.2rem', color: '#09090b' }}>
            Smart Trade AI
          </h3>
          <p style={{ fontSize: '0.85rem', color: '#52525b' }}>
            {mode === 'login' ? 'Sign in to access your second-hand electronics marketplace' : 'Register to buy, sell & predict second-hand prices'}
          </p>
        </div>

        {mode === 'login' ? (
          <form onSubmit={handleLoginSubmit}>
            <div className="input-group">
              <label className="input-label">Email or Phone Number</label>
              <input
                type="text"
                className="input-field"
                placeholder="rahul@smarttrade.ai"
                value={loginEmail}
                onChange={(e) => setLoginEmail(e.target.value)}
              />
            </div>

            <div className="input-group">
              <label className="input-label">Password</label>
              <input
                type="password"
                className="input-field"
                placeholder="••••••••"
                value={loginPassword}
                onChange={(e) => setLoginPassword(e.target.value)}
              />
            </div>

            <div style={{ textAlign: 'right', marginBottom: '16px' }}>
              <span style={{ fontSize: '0.8rem', color: '#7c3aed', fontWeight: 700, cursor: 'pointer' }}>
                Forgot Password?
              </span>
            </div>

            <button type="submit" className="btn-purple" style={{ marginBottom: '16px' }}>
              Sign In to Smart Trade AI
            </button>

            <div style={{ textAlign: 'center', fontSize: '0.85rem', color: '#52525b' }}>
              Don't have an account?{' '}
              <strong style={{ color: '#7c3aed', cursor: 'pointer' }} onClick={() => setMode('register')}>
                Register Now
              </strong>
            </div>
          </form>
        ) : (
          <form onSubmit={handleRegisterSubmit}>
            <div className="input-group">
              <label className="input-label">Full Name *</label>
              <input
                type="text"
                className="input-field"
                placeholder="e.g. Rahul Sharma"
                value={name}
                onChange={(e) => setName(e.target.value)}
              />
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px' }}>
              <div className="input-group">
                <label className="input-label">Email *</label>
                <input
                  type="email"
                  className="input-field"
                  placeholder="name@email.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                />
              </div>
              <div className="input-group">
                <label className="input-label">Phone Number *</label>
                <input
                  type="text"
                  className="input-field"
                  placeholder="+91 98765 43210"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                />
              </div>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px' }}>
              <div className="input-group">
                <label className="input-label">Password *</label>
                <input
                  type="password"
                  className="input-field"
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                />
              </div>
              <div className="input-group">
                <label className="input-label">Confirm Password *</label>
                <input
                  type="password"
                  className="input-field"
                  placeholder="••••••••"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                />
              </div>
            </div>

            <div className="input-group">
              <label className="input-label">Full Address *</label>
              <input
                type="text"
                className="input-field"
                placeholder="House / Street / Area"
                value={address}
                onChange={(e) => setAddress(e.target.value)}
              />
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '8px' }}>
              <div className="input-group">
                <label className="input-label">City *</label>
                <input
                  type="text"
                  className="input-field"
                  value={city}
                  onChange={(e) => setCity(e.target.value)}
                />
              </div>
              <div className="input-group">
                <label className="input-label">State *</label>
                <input
                  type="text"
                  className="input-field"
                  value={state}
                  onChange={(e) => setState(e.target.value)}
                />
              </div>
              <div className="input-group">
                <label className="input-label">Pincode *</label>
                <input
                  type="text"
                  className="input-field"
                  value={pincode}
                  onChange={(e) => setPincode(e.target.value)}
                />
              </div>
            </div>

            <button type="submit" className="btn-purple" style={{ margin: '12px 0 16px 0' }}>
              Complete Registration & Launch App
            </button>

            <div style={{ textAlign: 'center', fontSize: '0.85rem', color: '#52525b' }}>
              Already registered?{' '}
              <strong style={{ color: '#7c3aed', cursor: 'pointer' }} onClick={() => setMode('login')}>
                Sign In
              </strong>
            </div>
          </form>
        )}
      </div>
    </div>
  );
}
