import React, { useState } from 'react';
import {
  ArrowLeft,
  Heart,
  Sparkles,
  Phone,
  MessageSquare,
  MapPin,
  Navigation,
  ShieldCheck,
  CheckCircle2,
  AlertTriangle,
  Info,
  Clock,
  Wrench,
  Package,
  Calendar
} from 'lucide-react';
import { useApp } from '../context/AppContext';

export function ProductDetailScreen() {
  const { selectedProduct, wishlist, toggleFavorite, navigateTo, showToast } = useApp();
  const [showFullAddress, setShowFullAddress] = useState(false);

  if (!selectedProduct) {
    return (
      <div style={{ padding: '48px 20px', textAlign: 'center' }}>
        <p style={{ fontSize: '1.1rem', color: '#52525b' }}>No product selected.</p>
        <button className="btn-purple" onClick={() => navigateTo('home')} style={{ marginTop: '20px' }}>
          Back to Marketplace Home
        </button>
      </div>
    );
  }

  const isWishlisted = wishlist.includes(selectedProduct.id);
  const isSold = selectedProduct.status === 'Sold';
  const ai = selectedProduct.aiPredictedPrice || {};

  // Handle Call Seller - Launch native phone dialer
  const handleCallSeller = () => {
    if (isSold) {
      showToast('This product has already been SOLD.', 'error');
      return;
    }
    const phone = selectedProduct.sellerPhone || '+919876543210';
    showToast(`Opening Phone Dialer with ${phone}...`, 'info');
    window.location.href = `tel:${phone.replace(/\s+/g, '')}`;
  };

  // Handle Message Seller - Launch in-app chat
  const handleMessageSeller = () => {
    if (isSold) {
      showToast('This product has already been SOLD.', 'error');
      return;
    }
    navigateTo('chat_thread', {
      productId: selectedProduct.id,
      sellerId: selectedProduct.sellerId,
      sellerName: selectedProduct.sellerName,
      productName: selectedProduct.name,
      productImage: selectedProduct.image,
      sellingPrice: selectedProduct.sellingPrice
    });
  };

  // Handle Get Directions - Launch external Google Maps
  const handleGetDirections = () => {
    const query = encodeURIComponent(`${selectedProduct.sellerCity}, ${selectedProduct.sellerState}, ${selectedProduct.sellerPincode || ''}`);
    const mapsUrl = `https://www.google.com/maps/search/?api=1&query=${query}`;
    window.open(mapsUrl, '_blank');
  };

  return (
    <div style={{ paddingBottom: '40px' }}>
      {/* Top Header Controls */}
      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          marginBottom: '20px'
        }}
      >
        <button
          onClick={() => navigateTo('home')}
          className="btn-outline"
          style={{ padding: '8px 14px', borderRadius: '20px', fontSize: '0.85rem', gap: '6px' }}
        >
          <ArrowLeft size={16} /> Back to Products
        </button>
        <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
          <button
            onClick={() => toggleFavorite(selectedProduct.id)}
            className="btn-outline-purple"
            style={{ padding: '8px 16px', borderRadius: '20px', fontSize: '0.85rem', gap: '6px' }}
          >
            <Heart size={16} fill={isWishlisted ? '#ef4444' : 'none'} color={isWishlisted ? '#ef4444' : '#7c3aed'} />
            {isWishlisted ? 'Saved in Wishlist' : 'Add to Wishlist'}
          </button>
        </div>
      </div>

      {/* Main 2-Column Responsive Layout for Desktop */}
      <div className="product-detail-grid">
        {/* Left Column: Image Banner + AI Card + Location */}
        <div>
          {/* Main Image Container */}
          <div style={{ position: 'relative', width: '100%', height: '380px', backgroundColor: '#ffffff', borderRadius: '20px', overflow: 'hidden', border: '1px solid #e2e8f0', boxShadow: '0 4px 14px rgba(0,0,0,0.05)', marginBottom: '20px' }}>
            <img
              src={selectedProduct.image}
              alt={selectedProduct.name}
              style={{ width: '100%', height: '100%', objectFit: 'cover' }}
            />
            {isSold && (
              <div
                style={{
                  position: 'absolute',
                  inset: 0,
                  backgroundColor: 'rgba(9,9,11,0.75)',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  color: '#ffffff',
                  fontSize: '2rem',
                  fontWeight: 800,
                  fontFamily: 'Outfit, sans-serif',
                  letterSpacing: '2px'
                }}
              >
                ITEM SOLD
              </div>
            )}
          </div>

          {/* AI Valuation Card Badge */}
          {ai.recommendedPrice && (
            <div
              style={{
                backgroundColor: '#09090b',
                color: '#ffffff',
                borderRadius: '20px',
                padding: '20px',
                marginBottom: '20px',
                boxShadow: '0 10px 25px rgba(124,58,237,0.25)'
              }}
            >
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '10px' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '6px', color: '#a78bfa', fontWeight: 700, fontSize: '0.85rem' }}>
                  <Sparkles size={18} /> Smart AI Valuation Engine
                </div>
                <span style={{ backgroundColor: '#10b981', color: '#ffffff', fontSize: '11px', fontWeight: 800, padding: '3px 10px', borderRadius: '12px' }}>
                  {ai.confidenceScore || 94}% AI Confidence
                </span>
              </div>

              <div style={{ fontSize: '1rem', marginBottom: '6px', color: '#ffffff' }}>
                AI Estimated Market Resale Range:{' '}
                <strong style={{ color: '#a78bfa', fontSize: '1.1rem' }}>
                  ₹{ai.minimumPrice?.toLocaleString('en-IN')} – ₹{ai.maximumPrice?.toLocaleString('en-IN')}
                </strong>
              </div>

              <div style={{ fontSize: '0.85rem', color: '#d4d4d8', marginTop: '10px', borderTop: '1px solid #27272a', paddingTop: '10px', lineHeight: 1.5 }}>
                "{ai.reasoning}"
              </div>
            </div>
          )}

          {/* Seller Location & Map Directions Card */}
          <div className="card-white" style={{ marginBottom: '20px' }}>
            <h3 style={{ fontFamily: 'Outfit, sans-serif', fontWeight: 800, fontSize: '1.1rem', marginBottom: '12px', color: '#09090b', display: 'flex', alignItems: 'center', gap: '8px' }}>
              <MapPin size={18} color="#7c3aed" /> Seller Pickup Location
            </h3>

            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '14px' }}>
              <div>
                <h4 style={{ fontWeight: 800, fontSize: '1rem', color: '#09090b' }}>{selectedProduct.sellerName || 'Verified Seller'}</h4>
                <p style={{ fontSize: '0.85rem', color: '#52525b', marginTop: '2px' }}>
                  📍 {selectedProduct.sellerCity}, {selectedProduct.sellerState} ({selectedProduct.sellerPincode})
                </p>
              </div>
              <button
                onClick={() => setShowFullAddress(!showFullAddress)}
                style={{ background: 'none', border: '1px solid #7c3aed', color: '#7c3aed', padding: '6px 12px', borderRadius: '12px', fontSize: '0.8rem', fontWeight: 700, cursor: 'pointer' }}
              >
                {showFullAddress ? 'Hide Address' : 'View Address'}
              </button>
            </div>

            {showFullAddress && (
              <div style={{ backgroundColor: '#f8fafc', padding: '12px', borderRadius: '12px', fontSize: '0.85rem', color: '#27272a', marginBottom: '14px', border: '1px solid #e2e8f0' }}>
                <strong>Verified Address for Pickup:</strong>
                <p>{selectedProduct.sellerAddress || 'Sector 4, Main Market Layout'}</p>
                <p>{selectedProduct.sellerCity}, {selectedProduct.sellerState} - {selectedProduct.sellerPincode}</p>
              </div>
            )}

            <button className="btn-outline-purple" onClick={handleGetDirections} style={{ width: '100%', fontSize: '0.9rem' }}>
              <Navigation size={16} /> Get Directions via Google Maps
            </button>
          </div>
        </div>

        {/* Right Column: Title, Specs, Pricing & CTA */}
        <div>
          <div className="card-white" style={{ marginBottom: '20px' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '10px' }}>
              <span className="ai-badge">{selectedProduct.category}</span>
              <span className="ai-badge" style={{ backgroundColor: '#09090b', color: '#ffffff', borderColor: '#09090b' }}>
                Condition: {selectedProduct.condition}
              </span>
            </div>

            <h1 style={{ fontFamily: 'Outfit, sans-serif', fontSize: '1.6rem', fontWeight: 800, color: '#09090b', lineHeight: 1.3, marginBottom: '12px' }}>
              {selectedProduct.name}
            </h1>

            <div style={{ display: 'flex', alignItems: 'baseline', gap: '12px', marginBottom: '20px' }}>
              <span style={{ fontSize: '2rem', fontWeight: 800, color: '#7c3aed', fontFamily: 'Outfit, sans-serif' }}>
                ₹{selectedProduct.sellingPrice?.toLocaleString('en-IN')}
              </span>
              {selectedProduct.originalPrice && (
                <span style={{ fontSize: '1.05rem', color: '#71717a', textDecoration: 'line-through' }}>
                  MSRP: ₹{selectedProduct.originalPrice?.toLocaleString('en-IN')}
                </span>
              )}
            </div>

            {/* Action Call & Message Buttons */}
            {!isSold ? (
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '14px', marginBottom: '24px' }}>
                <button className="btn-black" onClick={handleCallSeller} style={{ padding: '14px' }}>
                  <Phone size={18} /> Call Seller
                </button>
                <button className="btn-purple" onClick={handleMessageSeller} style={{ padding: '14px' }}>
                  <MessageSquare size={18} /> Message Seller
                </button>
              </div>
            ) : (
              <div className="card-white" style={{ textAlign: 'center', color: '#71717a', fontWeight: 700, backgroundColor: '#f8fafc', marginBottom: '24px' }}>
                This item has been marked as SOLD. Buyer contact options are disabled.
              </div>
            )}

            {/* Detailed Specifications Grid */}
            <div style={{ borderTop: '1px solid #e2e8f0', paddingTop: '20px' }}>
              <h3 style={{ fontFamily: 'Outfit, sans-serif', fontWeight: 800, fontSize: '1.1rem', marginBottom: '14px', color: '#09090b', display: 'flex', alignItems: 'center', gap: '8px' }}>
                <Info size={18} color="#7c3aed" /> Detailed Hardware Specifications
              </h3>

              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(160px, 1fr))', gap: '14px', fontSize: '0.9rem', marginBottom: '16px' }}>
                <div>
                  <span style={{ color: '#71717a', fontSize: '0.78rem', fontWeight: 700, textTransform: 'uppercase' }}>BRAND & MODEL</span>
                  <p style={{ fontWeight: 700, color: '#09090b' }}>{selectedProduct.brand} {selectedProduct.model || ''}</p>
                </div>
                <div>
                  <span style={{ color: '#71717a', fontSize: '0.78rem', fontWeight: 700, textTransform: 'uppercase' }}>AGE & PURCHASE</span>
                  <p style={{ fontWeight: 700, color: '#09090b' }}>{selectedProduct.age || 'Used'} ({selectedProduct.purchaseYear || '2022'})</p>
                </div>
                <div>
                  <span style={{ color: '#71717a', fontSize: '0.78rem', fontWeight: 700, textTransform: 'uppercase' }}>WORKING STATUS</span>
                  <p style={{ fontWeight: 700, color: '#10b981' }}>{selectedProduct.workingStatus || 'Fully Working'}</p>
                </div>
                <div>
                  <span style={{ color: '#71717a', fontSize: '0.78rem', fontWeight: 700, textTransform: 'uppercase' }}>WARRANTY</span>
                  <p style={{ fontWeight: 700, color: selectedProduct.warrantyStatus === 'Active' ? '#10b981' : '#71717a' }}>
                    {selectedProduct.warrantyStatus || 'Expired'}
                  </p>
                </div>
              </div>

              <div style={{ borderTop: '1px dashed #e2e8f0', paddingTop: '14px', display: 'flex', flexDirection: 'column', gap: '12px', fontSize: '0.9rem' }}>
                <div>
                  <span style={{ color: '#71717a', fontSize: '0.78rem', fontWeight: 700 }}>KEY HARDWARE SPECS:</span>
                  <p style={{ color: '#09090b', fontWeight: 600, marginTop: '2px' }}>{selectedProduct.specs || 'N/A'}</p>
                </div>
                <div>
                  <span style={{ color: '#71717a', fontSize: '0.78rem', fontWeight: 700 }}>PHYSICAL CONDITION & DEFECTS:</span>
                  <p style={{ color: '#09090b', marginTop: '2px' }}>{selectedProduct.physicalCondition || 'Good'} • {selectedProduct.damage || 'No major damage'}</p>
                </div>
                <div>
                  <span style={{ color: '#71717a', fontSize: '0.78rem', fontWeight: 700 }}>INCLUDED ACCESSORIES:</span>
                  <p style={{ color: '#09090b', fontWeight: 600, marginTop: '2px' }}>
                    {selectedProduct.accessories && selectedProduct.accessories.length > 0
                      ? selectedProduct.accessories.join(', ')
                      : 'Main item only'}
                  </p>
                </div>
                <div>
                  <span style={{ color: '#71717a', fontSize: '0.78rem', fontWeight: 700 }}>REASON FOR SELLING:</span>
                  <p style={{ color: '#52525b', marginTop: '2px' }}>{selectedProduct.reasonForSelling || 'Upgraded device'}</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
