import React, { useState, useEffect } from 'react';
import { Sparkles, Camera, Upload, AlertTriangle, CheckCircle2, ShieldCheck, ChevronRight, ChevronLeft, MapPin, ArrowRight } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { predictPrice, verifyElectronicImage } from '../services/aiEngine';

const CATEGORIES = [
  'Smartphones',
  'Laptops',
  'PC Components',
  'Graphics Cards',
  'RAM',
  'Storage',
  'Accessories',
  'Audio Devices',
  'Cameras',
  'Other Electronics'
];

const ACCESSORY_OPTIONS = [
  'Original Charger',
  'Box & Bill',
  'Original Accessories',
  'Protective Case',
  'Aux Cable',
  'Extra Cables'
];

export function SellScreen() {
  const { currentUser, addProduct, navigateTo, showToast } = useApp();

  const [step, setStep] = useState(1);

  // Form State
  const [image, setImage] = useState('https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?auto=format&fit=crop&w=800&q=80');
  const [imageFile, setImageFile] = useState(null);
  const [isVerifyingImage, setIsVerifyingImage] = useState(false);
  const [imageVerification, setImageVerification] = useState({ isValid: true, message: 'Valid electronic product' });

  const [name, setName] = useState('');
  const [category, setCategory] = useState('Smartphones');
  const [brand, setBrand] = useState('');
  const [model, setModel] = useState('');
  const [purchaseYear, setPurchaseYear] = useState('2022');
  const [age, setAge] = useState('2');
  const [originalPrice, setOriginalPrice] = useState('');
  const [condition, setCondition] = useState('Good');
  const [workingStatus, setWorkingStatus] = useState('Fully Working');
  const [physicalCondition, setPhysicalCondition] = useState('Clean with minor scratches');
  const [usageDuration, setUsageDuration] = useState('1.5 years');
  const [damage, setDamage] = useState('None');
  const [missingComponents, setMissingComponents] = useState('None');
  const [selectedAccessories, setSelectedAccessories] = useState(['Original Charger', 'Box & Bill']);
  const [warrantyStatus, setWarrantyStatus] = useState('Expired');
  const [warrantyPeriod, setWarrantyPeriod] = useState('0');
  const [specs, setSpecs] = useState('');
  const [repairHistory, setRepairHistory] = useState('None');
  const [reasonForSelling, setReasonForSelling] = useState('Upgraded to newer model');

  // AI Prediction State
  const [aiResult, setAiResult] = useState(null);
  const [isPredicting, setIsPredicting] = useState(false);
  const [sellingPrice, setSellingPrice] = useState('');

  // Seller Location State (blank if no user profile)
  const [sellerCity, setSellerCity] = useState(currentUser?.city || 'Bengaluru');
  const [sellerState, setSellerState] = useState(currentUser?.state || 'Karnataka');
  const [sellerPincode, setSellerPincode] = useState(currentUser?.pincode || '560001');

  // Handle Image File Upload & AI Electronic Image Verification
  const handleImageUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setImageFile(file);
    setIsVerifyingImage(true);

    const reader = new FileReader();
    reader.onload = async (event) => {
      const dataUrl = event.target.result;
      setImage(dataUrl);

      // Run AI Electronic Product Image Classifier
      const verification = await verifyElectronicImage(file);
      setIsVerifyingImage(false);
      setImageVerification(verification);

      if (verification.isValid) {
        showToast('✅ Electronic product image verified by AI!', 'success');
      } else {
        showToast('❌ Invalid Image – Please upload an electronic product!', 'error');
      }
    };
    reader.readAsDataURL(file);
  };

  // Run AI Price Valuation Engine
  const handleRunAiPrediction = () => {
    if (!originalPrice || parseFloat(originalPrice) <= 0) {
      showToast('Please enter the Original / MSRP price first!', 'info');
      return;
    }

    setIsPredicting(true);
    setTimeout(() => {
      const result = predictPrice({
        name,
        category,
        brand,
        model,
        purchaseYear,
        age,
        originalPrice,
        condition,
        workingStatus,
        physicalCondition,
        usageDuration,
        damage,
        missingComponents,
        accessories: selectedAccessories,
        warrantyStatus,
        warrantyPeriod,
        specs,
        repairHistory,
        reasonForSelling
      });

      setAiResult(result);
      setSellingPrice(result.recommendedPrice);
      setIsPredicting(false);
      showToast('AI Price Valuation completed!', 'success');
    }, 500);
  };

  // Auto recalculate price if on Step 3 and attributes change
  useEffect(() => {
    if (step === 3 && originalPrice) {
      handleRunAiPrediction();
    }
  }, [condition, workingStatus, age, originalPrice, damage, warrantyStatus]);

  const toggleAccessory = (acc) => {
    if (selectedAccessories.includes(acc)) {
      setSelectedAccessories(selectedAccessories.filter(a => a !== acc));
    } else {
      setSelectedAccessories([...selectedAccessories, acc]);
    }
  };

  // Handle Publishing Product
  const handlePublish = () => {
    if (!name || !originalPrice || !sellingPrice) {
      showToast('Please complete required fields before publishing', 'error');
      return;
    }

    addProduct({
      name,
      category,
      brand: brand || 'Generic',
      model: model || name,
      purchaseYear,
      age: `${age} years`,
      originalPrice: parseFloat(originalPrice),
      sellingPrice: parseFloat(sellingPrice),
      aiPredictedPrice: aiResult,
      condition,
      workingStatus,
      physicalCondition,
      usageDuration,
      damage,
      missingComponents,
      accessories: selectedAccessories,
      warrantyStatus,
      warrantyPeriod,
      specs: specs || `${category} - Good condition`,
      repairHistory,
      reasonForSelling,
      image,
      sellerCity,
      sellerState,
      sellerPincode
    });
  };

  return (
    <div style={{ maxWidth: '800px', margin: '0 auto' }}>
      {/* Wizard Header & Progress */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '20px' }}>
        <div>
          <span style={{ fontSize: '0.8rem', fontWeight: 800, color: '#7c3aed', textTransform: 'uppercase' }}>
            Smart Marketplace Listing Wizard
          </span>
          <h2 style={{ fontFamily: 'Outfit, sans-serif', fontSize: '1.5rem', fontWeight: 800, color: '#09090b' }}>
            Sell Second-Hand Gadget
          </h2>
        </div>
        <span className="ai-badge" style={{ fontSize: '0.85rem', padding: '6px 14px' }}>
          Step {step} of 5
        </span>
      </div>

      {/* Step Indicator */}
      <div className="step-indicator">
        {[1, 2, 3, 4, 5].map((s) => (
          <div
            key={s}
            className={`step-dot ${step === s ? 'active' : step > s ? 'completed' : ''}`}
            onClick={() => s < step && setStep(s)}
            style={{ cursor: s < step ? 'pointer' : 'default' }}
          >
            {step > s ? '✓' : s}
          </div>
        ))}
      </div>

      {/* STEP 1: PRODUCT IMAGE & AI VERIFICATION */}
      {step === 1 && (
        <div className="card-white">
          <h3 style={{ fontFamily: 'Outfit, sans-serif', fontWeight: 800, fontSize: '1.2rem', marginBottom: '8px', color: '#09090b' }}>
            Step 1: Upload Product Photo
          </h3>
          <p style={{ fontSize: '0.9rem', color: '#52525b', marginBottom: '20px' }}>
            Upload a clear photo of your electronic item. Our AI will automatically verify if it's an electronic device.
          </p>

          <div
            style={{
              width: '100%',
              height: '280px',
              border: imageVerification.isValid ? '2px dashed #7c3aed' : '2px dashed #ef4444',
              borderRadius: '20px',
              backgroundColor: '#f8fafc',
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              justifyContent: 'center',
              position: 'relative',
              overflow: 'hidden',
              marginBottom: '20px'
            }}
          >
            {image ? (
              <img src={image} alt="Preview" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
            ) : (
              <div style={{ textAlign: 'center', padding: '20px' }}>
                <Camera size={48} color="#7c3aed" style={{ marginBottom: '12px' }} />
                <p style={{ fontWeight: 700, fontSize: '1rem', color: '#09090b' }}>Click or tap to select product photo</p>
                <p style={{ fontSize: '0.8rem', color: '#71717a', marginTop: '4px' }}>PNG, JPG or WEBP up to 10MB</p>
              </div>
            )}

            <input
              type="file"
              accept="image/*"
              onChange={handleImageUpload}
              style={{
                position: 'absolute',
                inset: 0,
                opacity: 0,
                cursor: 'pointer'
              }}
            />
          </div>

          {/* AI Image Verification Alert Box */}
          {isVerifyingImage ? (
            <div className="ai-badge-dark" style={{ width: '100%', justifyContent: 'center', marginBottom: '20px', padding: '10px' }}>
              <Sparkles className="spin" size={18} color="#a78bfa" /> Running AI Electronic Image Verification...
            </div>
          ) : !imageVerification.isValid ? (
            <div
              style={{
                backgroundColor: '#fef2f2',
                border: '1.5px solid #fca5a5',
                color: '#991b1b',
                padding: '14px',
                borderRadius: '14px',
                fontSize: '0.9rem',
                fontWeight: 700,
                display: 'flex',
                alignItems: 'center',
                gap: '10px',
                marginBottom: '20px'
              }}
            >
              <AlertTriangle size={22} color="#ef4444" />
              <span>{imageVerification.message}</span>
            </div>
          ) : (
            <div
              style={{
                backgroundColor: '#f0fdf4',
                border: '1.5px solid #86efac',
                color: '#166534',
                padding: '14px',
                borderRadius: '14px',
                fontSize: '0.9rem',
                fontWeight: 700,
                display: 'flex',
                alignItems: 'center',
                gap: '10px',
                marginBottom: '20px'
              }}
            >
              <CheckCircle2 size={20} color="#10b981" />
              <span>AI Verified: Valid Electronic Product Image ({Math.round((imageVerification.confidence || 0.94) * 100)}% Confidence)</span>
            </div>
          )}

          <button
            className="btn-purple"
            disabled={!imageVerification.isValid}
            onClick={() => {
              if (imageVerification.isValid) setStep(2);
            }}
            style={{ width: '100%', opacity: imageVerification.isValid ? 1 : 0.5, padding: '14px' }}
          >
            Continue to Product Specifications <ChevronRight size={20} />
          </button>
        </div>
      )}

      {/* STEP 2: DETAILED PRODUCT INFORMATION FORM */}
      {step === 2 && (
        <div className="card-white">
          <h3 style={{ fontFamily: 'Outfit, sans-serif', fontWeight: 800, fontSize: '1.2rem', marginBottom: '18px', color: '#09090b' }}>
            Step 2: Enter Specifications & Attributes
          </h3>

          <div className="input-group">
            <label className="input-label">Product Title *</label>
            <input
              type="text"
              className="input-field"
              placeholder="e.g. Samsung Galaxy S21 5G 128GB (Phantom Gray)"
              value={name}
              onChange={(e) => setName(e.target.value)}
            />
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: '14px' }}>
            <div className="input-group">
              <label className="input-label">Category *</label>
              <select
                className="select-field"
                value={category}
                onChange={(e) => setCategory(e.target.value)}
              >
                {CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>
            <div className="input-group">
              <label className="input-label">Brand *</label>
              <input
                type="text"
                className="input-field"
                placeholder="e.g. Samsung, Apple, Asus, Sony"
                value={brand}
                onChange={(e) => setBrand(e.target.value)}
              />
            </div>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: '14px' }}>
            <div className="input-group">
              <label className="input-label">Model Number / Code</label>
              <input
                type="text"
                className="input-field"
                placeholder="e.g. SM-G991B"
                value={model}
                onChange={(e) => setModel(e.target.value)}
              />
            </div>
            <div className="input-group">
              <label className="input-label">Original Price (₹ MSRP) *</label>
              <input
                type="number"
                className="input-field"
                placeholder="e.g. 70000"
                value={originalPrice}
                onChange={(e) => setOriginalPrice(e.target.value)}
              />
            </div>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: '14px' }}>
            <div className="input-group">
              <label className="input-label">Purchase Year</label>
              <input
                type="number"
                className="input-field"
                value={purchaseYear}
                onChange={(e) => {
                  setPurchaseYear(e.target.value);
                  const calculatedAge = new Date().getFullYear() - parseInt(e.target.value || '2024');
                  setAge(Math.max(0.5, calculatedAge).toString());
                }}
              />
            </div>
            <div className="input-group">
              <label className="input-label">Current Age (Years)</label>
              <input
                type="number"
                step="0.5"
                className="input-field"
                value={age}
                onChange={(e) => setAge(e.target.value)}
              />
            </div>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: '14px' }}>
            <div className="input-group">
              <label className="input-label">Product Condition</label>
              <select
                className="select-field"
                value={condition}
                onChange={(e) => setCondition(e.target.value)}
              >
                <option value="Like New">Like New (Unused / Flawless)</option>
                <option value="Good">Good (Minor normal usage)</option>
                <option value="Fair">Fair (Noticeable wear)</option>
                <option value="Poor">Poor (Heavy wear or defect)</option>
              </select>
            </div>
            <div className="input-group">
              <label className="input-label">Working Status</label>
              <select
                className="select-field"
                value={workingStatus}
                onChange={(e) => setWorkingStatus(e.target.value)}
              >
                <option value="Fully Working">Fully Working (100% Functional)</option>
                <option value="Minor Issues">Minor Issues (Battery degraded, soft key issue)</option>
                <option value="Major Faults">Major Faults (Screen defect, port issue)</option>
              </select>
            </div>
          </div>

          <div className="input-group">
            <label className="input-label">Physical Condition & Scratches</label>
            <input
              type="text"
              className="input-field"
              placeholder="e.g. Minor hairline scratches on back body"
              value={physicalCondition}
              onChange={(e) => setPhysicalCondition(e.target.value)}
            />
          </div>

          <div className="input-group">
            <label className="input-label">Damage / Defects (If Any)</label>
            <input
              type="text"
              className="input-field"
              placeholder="e.g. Tiny dent on side bezel or None"
              value={damage}
              onChange={(e) => setDamage(e.target.value)}
            />
          </div>

          <div className="input-group">
            <label className="input-label">Accessories Included</label>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: '10px', marginTop: '6px' }}>
              {ACCESSORY_OPTIONS.map((acc) => {
                const isSel = selectedAccessories.includes(acc);
                return (
                  <button
                    key={acc}
                    type="button"
                    onClick={() => toggleAccessory(acc)}
                    style={{
                      padding: '8px 14px',
                      borderRadius: '20px',
                      fontSize: '0.82rem',
                      fontWeight: 700,
                      border: isSel ? '1.5px solid #7c3aed' : '1.5px solid #e2e8f0',
                      backgroundColor: isSel ? '#f5f3ff' : '#ffffff',
                      color: isSel ? '#7c3aed' : '#52525b',
                      cursor: 'pointer',
                      transition: 'all 0.2s ease'
                    }}
                  >
                    {isSel ? '✓ ' : '+ '}{acc}
                  </button>
                );
              })}
            </div>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '14px' }}>
            <div className="input-group">
              <label className="input-label">Warranty Status</label>
              <select
                className="select-field"
                value={warrantyStatus}
                onChange={(e) => setWarrantyStatus(e.target.value)}
              >
                <option value="Active">Active Warranty</option>
                <option value="Expired">Expired Warranty</option>
              </select>
            </div>
            <div className="input-group">
              <label className="input-label">Remaining Months</label>
              <input
                type="number"
                className="input-field"
                value={warrantyPeriod}
                onChange={(e) => setWarrantyPeriod(e.target.value)}
                disabled={warrantyStatus === 'Expired'}
              />
            </div>
          </div>

          <div className="input-group">
            <label className="input-label">Key Specifications (RAM, Storage, GPU, etc.)</label>
            <input
              type="text"
              className="input-field"
              placeholder="e.g. 8GB RAM | 128GB Storage | Exynos 2100 | 120Hz AMOLED"
              value={specs}
              onChange={(e) => setSpecs(e.target.value)}
            />
          </div>

          <div className="input-group">
            <label className="input-label">Previous Repair History</label>
            <input
              type="text"
              className="input-field"
              placeholder="e.g. None - All original parts"
              value={repairHistory}
              onChange={(e) => setRepairHistory(e.target.value)}
            />
          </div>

          <div style={{ display: 'flex', gap: '12px', marginTop: '24px' }}>
            <button className="btn-black" onClick={() => setStep(1)} style={{ width: '35%' }}>
              <ChevronLeft size={18} /> Back
            </button>
            <button
              className="btn-purple"
              style={{ flex: 1 }}
              onClick={() => {
                if (!name || !originalPrice) {
                  showToast('Please enter Title and Original Price!', 'error');
                  return;
                }
                setStep(3);
                handleRunAiPrediction();
              }}
            >
              Run AI Price Valuation <Sparkles size={18} />
            </button>
          </div>
        </div>
      )}

      {/* STEP 3: AI PRICE PREDICTION DISPLAY & ADJUSTMENT */}
      {step === 3 && (
        <div className="card-white">
          <div style={{ textAlign: 'center', marginBottom: '20px' }}>
            <div className="ai-badge-dark" style={{ display: 'inline-flex', marginBottom: '10px' }}>
              <Sparkles size={18} color="#a78bfa" /> AI Valuation Output
            </div>
            <h3 style={{ fontFamily: 'Outfit, sans-serif', fontWeight: 800, fontSize: '1.4rem', color: '#09090b' }}>
              Recommended Resale Market Value
            </h3>
          </div>

          {isPredicting || !aiResult ? (
            <div style={{ textAlign: 'center', padding: '50px 0' }}>
              <Sparkles className="spin" size={48} color="#7c3aed" style={{ marginBottom: '16px' }} />
              <p style={{ fontWeight: 700, fontSize: '1.05rem' }}>Processing product attributes through AI regression model...</p>
            </div>
          ) : (
            <>
              {/* Estimated Price Range Card */}
              <div
                style={{
                  backgroundColor: '#09090b',
                  color: '#ffffff',
                  borderRadius: '20px',
                  padding: '28px',
                  textAlign: 'center',
                  marginBottom: '20px',
                  boxShadow: '0 12px 30px rgba(124, 58, 237, 0.25)'
                }}
              >
                <span style={{ fontSize: '0.8rem', fontWeight: 700, color: '#a78bfa', letterSpacing: '0.5px' }}>
                  AI ESTIMATED RESALE RANGE
                </span>
                <h1 style={{ fontFamily: 'Outfit, sans-serif', fontSize: '2.4rem', fontWeight: 800, margin: '10px 0', color: '#ffffff' }}>
                  ₹{aiResult.minimumPrice?.toLocaleString('en-IN')} – ₹{aiResult.maximumPrice?.toLocaleString('en-IN')}
                </h1>
                <div
                  style={{
                    backgroundColor: '#7c3aed',
                    color: '#ffffff',
                    display: 'inline-block',
                    padding: '8px 22px',
                    borderRadius: '20px',
                    fontSize: '0.95rem',
                    fontWeight: 800,
                    marginTop: '6px'
                  }}
                >
                  Recommended Price: ₹{aiResult.recommendedPrice?.toLocaleString('en-IN')}
                </div>
                <div style={{ fontSize: '0.85rem', color: '#a1a1aa', marginTop: '12px' }}>
                  AI Valuation Confidence: <strong style={{ color: '#10b981' }}>{aiResult.confidenceScore}%</strong>
                </div>
              </div>

              {/* AI Reasoning Explanation Box */}
              <div
                style={{
                  backgroundColor: '#f8fafc',
                  border: '1.5px solid #e2e8f0',
                  borderRadius: '16px',
                  padding: '18px',
                  fontSize: '0.9rem',
                  color: '#27272a',
                  lineHeight: '1.6',
                  marginBottom: '20px'
                }}
              >
                <div style={{ display: 'flex', alignItems: 'center', gap: '6px', fontWeight: 800, color: '#7c3aed', marginBottom: '6px' }}>
                  <ShieldCheck size={18} /> AI Valuation Rationale
                </div>
                <p>"{aiResult.reasoning}"</p>
              </div>

              {/* Seller Price Input */}
              <div className="input-group" style={{ marginBottom: '20px' }}>
                <label className="input-label">Set Your Final Asking Price (₹)</label>
                <input
                  type="number"
                  className="input-field"
                  style={{ fontSize: '1.25rem', fontWeight: 800, color: '#7c3aed' }}
                  value={sellingPrice}
                  onChange={(e) => setSellingPrice(e.target.value)}
                />
                <span style={{ fontSize: '0.8rem', color: '#71717a', marginTop: '4px' }}>
                  You can adopt the AI suggested price or adjust manually for quick sale.
                </span>
              </div>

              <div style={{ display: 'flex', gap: '12px' }}>
                <button className="btn-black" onClick={() => setStep(2)} style={{ width: '35%' }}>
                  <ChevronLeft size={18} /> Edit Specs
                </button>
                <button className="btn-purple" onClick={() => setStep(4)} style={{ flex: 1 }}>
                  Confirm & Set Location <ChevronRight size={18} />
                </button>
              </div>
            </>
          )}
        </div>
      )}

      {/* STEP 4: SELLER PICKUP LOCATION */}
      {step === 4 && (
        <div className="card-white">
          <h3 style={{ fontFamily: 'Outfit, sans-serif', fontWeight: 800, fontSize: '1.2rem', marginBottom: '8px', color: '#09090b' }}>
            Step 4: Seller Location
          </h3>
          <p style={{ fontSize: '0.9rem', color: '#52525b', marginBottom: '20px' }}>
            Specify the pickup location where buyers can view or collect the item.
          </p>

          <div className="input-group">
            <label className="input-label">City *</label>
            <input
              type="text"
              className="input-field"
              value={sellerCity}
              onChange={(e) => setSellerCity(e.target.value)}
            />
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '14px' }}>
            <div className="input-group">
              <label className="input-label">State *</label>
              <input
                type="text"
                className="input-field"
                value={sellerState}
                onChange={(e) => setSellerState(e.target.value)}
              />
            </div>
            <div className="input-group">
              <label className="input-label">Pincode *</label>
              <input
                type="text"
                className="input-field"
                value={sellerPincode}
                onChange={(e) => setSellerPincode(e.target.value)}
              />
            </div>
          </div>

          <div style={{ display: 'flex', gap: '12px', marginTop: '20px' }}>
            <button className="btn-black" onClick={() => setStep(3)} style={{ width: '35%' }}>
              <ChevronLeft size={18} /> Back
            </button>
            <button className="btn-purple" onClick={() => setStep(5)} style={{ flex: 1 }}>
              Preview Final Listing <ChevronRight size={18} />
            </button>
          </div>
        </div>
      )}

      {/* STEP 5: PREVIEW & PUBLISH */}
      {step === 5 && (
        <div className="card-white">
          <h3 style={{ fontFamily: 'Outfit, sans-serif', fontWeight: 800, fontSize: '1.2rem', marginBottom: '16px', color: '#09090b' }}>
            Step 5: Listing Summary Preview
          </h3>

          <div style={{ border: '1px solid #e2e8f0', borderRadius: '16px', overflow: 'hidden', marginBottom: '20px', display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))', gap: '16px' }}>
            <img src={image} alt="Preview" style={{ width: '100%', height: '220px', objectFit: 'cover' }} />
            <div style={{ padding: '16px', display: 'flex', flexDirection: 'column', justifyContent: 'center' }}>
              <div style={{ display: 'flex', gap: '6px', marginBottom: '6px' }}>
                <span className="ai-badge">{category}</span>
                <span className="ai-badge" style={{ backgroundColor: '#09090b', color: '#ffffff' }}>{condition}</span>
              </div>
              <h4 style={{ fontSize: '1.1rem', fontWeight: 800, color: '#09090b', margin: '4px 0' }}>{name}</h4>
              <div style={{ fontSize: '1.5rem', fontWeight: 800, color: '#7c3aed', fontFamily: 'Outfit, sans-serif', margin: '6px 0' }}>
                Asking Price: ₹{parseFloat(sellingPrice || 0).toLocaleString('en-IN')}
              </div>
              <div style={{ fontSize: '0.85rem', color: '#52525b', marginTop: '4px' }}>
                📍 Pickup Location: {sellerCity}, {sellerState} ({sellerPincode})
              </div>
            </div>
          </div>

          <div style={{ display: 'flex', gap: '12px' }}>
            <button className="btn-black" onClick={() => setStep(4)} style={{ width: '35%' }}>
              <ChevronLeft size={18} /> Back
            </button>
            <button className="btn-purple" onClick={handlePublish} style={{ flex: 1, padding: '14px', fontSize: '1rem' }}>
              🚀 Publish Listing to Marketplace
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
