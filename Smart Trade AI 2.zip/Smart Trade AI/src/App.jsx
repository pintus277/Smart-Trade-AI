import React from 'react';
import { AppProvider } from './context/AppContext';
import { WebFrame } from './components/WebFrame';

export default function App() {
  return (
    <AppProvider>
      <WebFrame />
    </AppProvider>
  );
}

