import React from 'react';
import { Cpu, Heart, MessageSquare, PlusCircle, Search, Home, User, LogIn, UserPlus } from 'lucide-react';
import { useApp } from '../context/AppContext';

export function Navbar() {
  const { wishlist, messages, activeScreen, navigateTo, currentUser, searchQuery, setSearchQuery } = useApp();

  const unreadCount = messages.filter(m => !m.readStatus && m.receiverId === currentUser?.id).length;

  return (
    <header className="top-navbar">
      <div className="navbar-container">
        {/* Brand Logo */}
        <div className="brand-logo" onClick={() => navigateTo('home')} style={{ cursor: 'pointer' }}>
          <div className="brand-icon">
            <Cpu size={22} />
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', lineHeight: 1 }}>
            <div style={{ display: 'flex', alignItems: 'center' }}>
              <span>Smart Trade</span>
              <span className="brand-badge">AI</span>
            </div>
            <span style={{ fontSize: '10px', color: '#64748b', fontWeight: 600, letterSpacing: '0.2px', marginTop: '2px' }}>
              Second-Hand Electronics
            </span>
          </div>
        </div>

        {/* Header Desktop Search Bar */}
        <div className="header-search-bar">
          <Search size={16} color="#71717a" className="header-search-icon" />
          <input
            type="text"
            className="header-search-input"
            placeholder="Search phones, laptops, GPUs, RAM..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter') navigateTo('search');
            }}
          />
        </div>

        {/* Desktop Navigation Links */}
        <nav className="desktop-nav-links">
          <button
            className={`desktop-nav-btn ${activeScreen === 'home' ? 'active' : ''}`}
            onClick={() => navigateTo('home')}
          >
            <Home size={17} />
            <span>Home</span>
          </button>

          <button
            className={`desktop-nav-btn ${activeScreen === 'search' ? 'active' : ''}`}
            onClick={() => navigateTo('search')}
          >
            <Search size={17} />
            <span>Browse</span>
          </button>

          <button
            className={`desktop-nav-btn sell-btn ${activeScreen === 'sell' ? 'active' : ''}`}
            onClick={() => navigateTo('sell')}
          >
            <PlusCircle size={17} />
            <span>Sell Gadget</span>
          </button>

          <button
            className={`desktop-nav-btn ${activeScreen === 'messages' ? 'active' : ''}`}
            onClick={() => navigateTo('messages')}
            style={{ position: 'relative' }}
          >
            <MessageSquare size={17} />
            <span>Messages</span>
            {unreadCount > 0 && (
              <span className="nav-badge">{unreadCount}</span>
            )}
          </button>

          <button
            className={`desktop-nav-btn ${activeScreen === 'wishlist' ? 'active' : ''}`}
            onClick={() => navigateTo('wishlist')}
            style={{ position: 'relative' }}
          >
            <Heart size={17} fill={wishlist.length > 0 ? '#ef4444' : 'none'} color={wishlist.length > 0 ? '#ef4444' : 'currentColor'} />
            <span>Wishlist</span>
            {wishlist.length > 0 && (
              <span className="nav-badge purple">{wishlist.length}</span>
            )}
          </button>
        </nav>

        {/* Right User Actions */}
        <div className="header-user-actions">
          {currentUser ? (
            <button
              onClick={() => navigateTo('profile')}
              className={`user-profile-btn ${activeScreen === 'profile' ? 'active' : ''}`}
            >
              <div className="user-avatar-circle">
                {currentUser.name ? currentUser.name.charAt(0).toUpperCase() : 'U'}
              </div>
              <span className="user-name-text">{currentUser.name.split(' ')[0]}</span>
            </button>
          ) : (
            <div style={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
              <button
                onClick={() => navigateTo('login')}
                className="btn-outline"
                style={{ padding: '7px 14px', fontSize: '0.85rem', borderRadius: '20px' }}
              >
                <LogIn size={15} /> Login
              </button>
              <button
                onClick={() => navigateTo('register')}
                className="btn-purple"
                style={{ padding: '7px 16px', fontSize: '0.85rem', borderRadius: '20px' }}
              >
                <UserPlus size={15} /> Register
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}
