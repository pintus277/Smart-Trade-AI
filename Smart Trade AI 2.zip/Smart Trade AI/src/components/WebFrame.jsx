import React from 'react';
import { Navbar } from './Navbar';
import { BottomNav } from './BottomNav';
import { useApp } from '../context/AppContext';

import { HomeScreen } from '../screens/HomeScreen';
import { SearchScreen } from '../screens/SearchScreen';
import { SellScreen } from '../screens/SellScreen';
import { ProductDetailScreen } from '../screens/ProductDetailScreen';
import { ChatScreen } from '../screens/ChatScreen';
import { MyProductsScreen } from '../screens/MyProductsScreen';
import { WishlistScreen } from '../screens/WishlistScreen';
import { ProfileScreen } from '../screens/ProfileScreen';
import { LoginScreen } from '../screens/LoginScreen';
import { RegisterScreen } from '../screens/RegisterScreen';
import { CheckCircle2, AlertTriangle, Info, Cpu, Heart, ShieldCheck, Sparkles } from 'lucide-react';

export function WebFrame() {
  const { activeScreen, toast, navigateTo } = useApp();

  const renderScreen = () => {
    switch (activeScreen) {
      case 'home':
        return <HomeScreen />;
      case 'search':
        return <SearchScreen />;
      case 'sell':
        return <SellScreen />;
      case 'product_detail':
        return <ProductDetailScreen />;
      case 'messages':
        return <ChatScreen />;
      case 'my_products':
        return <MyProductsScreen />;
      case 'wishlist':
        return <WishlistScreen />;
      case 'profile':
        return <ProfileScreen />;
      case 'auth':
      case 'login':
        return <LoginScreen />;
      case 'register':
        return <RegisterScreen />;
      default:
        return <HomeScreen />;
    }
  };

  return (
    <div className="web-viewport">
      {/* Desktop & Mobile Header Navigation */}
      <Navbar />

      {/* Global Toast Notification Banner */}
      {toast && (
        <div className="toast-notification">
          {toast.type === 'success' ? (
            <CheckCircle2 size={18} color="#10b981" />
          ) : toast.type === 'error' ? (
            <AlertTriangle size={18} color="#ef4444" />
          ) : (
            <Info size={18} color="#7c3aed" />
          )}
          <span style={{ fontSize: '0.88rem', fontWeight: 600 }}>{toast.message}</span>
        </div>
      )}

      {/* Main Responsive App Content Area */}
      <main className="web-main-content">
        <div className="web-container">{renderScreen()}</div>
      </main>

      {/* Mobile Bottom Navigation Bar (Hidden on Desktop) */}
      <BottomNav />

      {/* Desktop Web Footer */}
      <footer className="web-footer">
        <div className="web-container footer-content">
          <div className="footer-brand">
            <div className="brand-logo" onClick={() => navigateTo('home')} style={{ cursor: 'pointer' }}>
              <div className="brand-icon">
                <Cpu size={20} />
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', lineHeight: 1 }}>
                <div style={{ display: 'flex', alignItems: 'center' }}>
                  <span>Smart Trade</span>
                  <span className="brand-badge">AI</span>
                </div>
                <span style={{ fontSize: '11px', color: '#a1a1aa', fontWeight: 600, letterSpacing: '0.2px', marginTop: '3px' }}>
                  Second-Hand Electronics Marketplace
                </span>
              </div>
            </div>
            <p className="footer-tagline">
              AI-driven valuation, verified electronic product image checks, and instant buyer-seller connectivity.
            </p>
          </div>

          <div className="footer-links-grid">
            <div className="footer-col">
              <h4>Marketplace</h4>
              <button onClick={() => navigateTo('home')}>Featured Products</button>
              <button onClick={() => navigateTo('search')}>Browse Electronics</button>
              <button onClick={() => navigateTo('sell')}>Sell & Predict Price</button>
            </div>
            <div className="footer-col">
              <h4>User Account</h4>
              <button onClick={() => navigateTo('profile')}>Seller Profile</button>
              <button onClick={() => navigateTo('my_products')}>My Listings</button>
              <button onClick={() => navigateTo('wishlist')}>Saved Wishlist</button>
            </div>
            <div className="footer-col">
              <h4>Smart Features</h4>
              <span className="footer-feature-tag"><Sparkles size={12} color="#a78bfa" /> ML Price Regression</span>
              <span className="footer-feature-tag"><ShieldCheck size={12} color="#10b981" /> AI Image Classifier</span>
            </div>
          </div>
        </div>
        <div className="footer-bottom">
          <div className="web-container footer-bottom-flex">
            <span>© {new Date().getFullYear()} Smart Trade AI. All rights reserved.</span>
            <span>Premium Second-Hand Electronics Trading Platform</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
