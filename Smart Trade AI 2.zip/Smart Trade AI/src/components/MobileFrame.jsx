import React from 'react';
import { StatusHeader } from './StatusHeader';
import { Navbar } from './Navbar';
import { BottomNav } from './BottomNav';
import { useApp } from '../context/AppContext';

import { HomeScreen } from '../screens/HomeScreen';
import { SearchScreen } from '../screens/SearchScreen';
import { SellScreen } from '../screens/SellScreen';
import { ProductDetailScreen } from '../screens/ProductDetailScreen';
import { ChatScreen } from '../screens/ChatScreen';
import { MyProductsScreen } from '../screens/MyProductsScreen';
import { WishlistScreen } from '../screens/WishlistScreen';
import { ProfileScreen } from '../screens/ProfileScreen';
import { AuthScreen } from '../screens/AuthScreen';
import { LoginScreen } from '../screens/LoginScreen';
import { RegisterScreen } from '../screens/RegisterScreen';
import { CheckCircle2, AlertTriangle, Info } from 'lucide-react';

export function MobileFrame() {
  const { activeScreen, toast } = useApp();

  const renderScreen = () => {
    switch (activeScreen) {
      case 'home':
        return <HomeScreen />;
      case 'search':
        return <SearchScreen />;
      case 'sell':
        return <SellScreen />;
      case 'product_detail':
        return <ProductDetailScreen />;
      case 'messages':
        return <ChatScreen />;
      case 'my_products':
        return <MyProductsScreen />;
      case 'wishlist':
        return <WishlistScreen />;
      case 'profile':
        return <ProfileScreen />;
      case 'auth':
      case 'login':
        return <LoginScreen />;
      case 'register':
        return <RegisterScreen />;
      default:
        return <HomeScreen />;
    }
  };

  return (
    <div className="app-viewport">
      <StatusHeader />
      <Navbar />

      {/* Toast Banner */}
      {toast && (
        <div className="toast-notification">
          {toast.type === 'success' ? (
            <CheckCircle2 size={18} color="#10b981" />
          ) : toast.type === 'error' ? (
            <AlertTriangle size={18} color="#ef4444" />
          ) : (
            <Info size={18} color="#7c3aed" />
          )}
          <span style={{ fontSize: '0.85rem', fontWeight: 600 }}>{toast.message}</span>
        </div>
      )}

      <main className="main-content">{renderScreen()}</main>

      <BottomNav />
    </div>
  );
}
