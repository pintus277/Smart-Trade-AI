import React from 'react';
import { Home, Search, PlusCircle, MessageSquare, User } from 'lucide-react';
import { useApp } from '../context/AppContext';

export function BottomNav() {
  const { activeScreen, navigateTo, messages, currentUser } = useApp();

  const unreadCount = messages.filter(m => !m.readStatus && m.receiverId === currentUser?.id).length;

  const navItems = [
    { id: 'home', label: 'Home', icon: Home },
    { id: 'search', label: 'Search', icon: Search },
    { id: 'sell', label: 'Sell', icon: PlusCircle, isHighlight: true },
    { id: 'messages', label: 'Messages', icon: MessageSquare, badge: unreadCount },
    { id: 'profile', label: 'Profile', icon: User }
  ];

  return (
    <nav className="bottom-nav">
      {navItems.map((item) => {
        const Icon = item.icon;
        const isActive = activeScreen === item.id;

        return (
          <button
            key={item.id}
            className={`nav-item ${isActive ? 'active' : ''}`}
            onClick={() => navigateTo(item.id)}
          >
            <div className="nav-icon-container" style={{ position: 'relative' }}>
              <Icon size={item.isHighlight ? 22 : 20} color={isActive ? '#ffffff' : (item.isHighlight ? '#7c3aed' : '#a1a1aa')} />
              {item.badge > 0 && (
                <span
                  style={{
                    position: 'absolute',
                    top: '-2px',
                    right: '-2px',
                    backgroundColor: '#ef4444',
                    color: '#ffffff',
                    fontSize: '9px',
                    fontWeight: 800,
                    width: '14px',
                    height: '14px',
                    borderRadius: '50%',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center'
                  }}
                >
                  {item.badge}
                </span>
              )}
            </div>
            <span>{item.label}</span>
          </button>
        );
      })}
    </nav>
  );
}
